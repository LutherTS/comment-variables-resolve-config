export const resolvedConfigData = /** @type {{"jsDoc":{"definitions":{"escapeRegex":{"value":"Escapes all regex characters with a `\"\\\"` in a string to prepare it for use in a regex.","key":"JSDOC#DEFINITIONS#ESCAPEREGEX"},"makeIsolatedStringRegex":{"value":"Makes a global regex for a given string that ensures it is surrounded by whitespace.","key":"JSDOC#DEFINITIONS#MAKEISOLATEDSTRINGREGEX"},"flattenConfigData":{"value":"Flattens the config's data property into a one-dimensional object of `COMMENT#COMMENT`-like keys and string values. (This function is now also used to flatten variation data.)","key":"JSDOC#DEFINITIONS#FLATTENCONFIGDATA"},"resolveConfig":{"value":"Verifies, validates and resolves the config path to retrieve the config's data, ignores, and more.","key":"JSDOC#DEFINITIONS#RESOLVECONFIG"},"makeSuccessFalseTypeError":{"value":"Makes a `{success: false}` object with a single error in its errors array of `{type: \"error\"}` based on the message it is meant to display.","key":"JSDOC#DEFINITIONS#MAKESUCCESSFALSETYPEERROR"},"extractValueLocationsFromLintMessages":{"value":"Extracts and format the output JSON from an ESLint rule's `context.report` to turn it into Value Locations.","key":"JSDOC#DEFINITIONS#EXTRACTVALUELOCATIONSFROMLINTMESSAGES"},"reverseFlattenedConfigData":{"value":"Reverses the keys and the values of a flattened config data object.","key":"JSDOC#DEFINITIONS#REVERSEFLATTENEDCONFIGDATA"},"resolveComposedVariable":{"value":"Resolves a composed variable, as in a string made of several comment variables, to the actual Comment Variable it is meant to represent.","key":"JSDOC#DEFINITIONS#RESOLVECOMPOSEDVARIABLE"},"resolveConfigDataStringValue":{"value":"Resolves a string value from Comment Variables config data taking into account the possibility that it is first an alias variable, second (and on the alias route) a composed variable, third (also on the alias route) a comment variable.","key":"JSDOC#DEFINITIONS#RESOLVECONFIGDATASTRINGVALUE"},"resolveConfigData":{"value":"Recursively resolves Comment Variables config data values (being strings or nested objects) to generate an object with the same keys and the same shape as the original config data now with all string values entirely resolved.","key":"JSDOC#DEFINITIONS#RESOLVECONFIGDATA"},"makeResolvedConfigData":{"value":"Creates that object with the same keys and the same base shape as the original config data now with all string values entirely resolved alongside Comment Variables keys.","key":"JSDOC#DEFINITIONS#MAKERESOLVEDCONFIGDATA"},"freshImport":{"value":"Guarantees a fresh import of the config, negating the innate (and hidden) cache of the dynamic `import` utility.","key":"JSDOC#DEFINITIONS#FRESHIMPORT"},"transformResolvedConfigData":{"value":"Transforms resolved config data with keys alongside values.","key":"JSDOC#DEFINITIONS#TRANSFORMRESOLVEDCONFIGDATA"},"normalize":{"value":"Normalizes a Comment Variables key part.","key":"JSDOC#DEFINITIONS#NORMALIZE"},"makeNormalizedKey":{"value":"Normalizes and makes a Comment Variable key from the list of keys that trace to its value.","key":"JSDOC#DEFINITIONS#MAKENORMALIZEDKEY"},"makeJsonData":{"value":"Makes the JSON resolved config data to be written at an expected `.json` path.","key":"JSDOC#DEFINITIONS#MAKEJSONDATA"},"makeMjsData":{"value":"Makes the MJS resolved config data to be written at an expected `.mjs` path.","key":"JSDOC#DEFINITIONS#MAKEMJSDATA"},"makeJsonPathLog":{"value":"Makes the log that announces the writing of the JSON resolved config data.","key":"JSDOC#DEFINITIONS#MAKEJSONPATHLOG"},"makeMjsPathLog":{"value":"Makes the log that announces the writing of the MJS resolved config data.","key":"JSDOC#DEFINITIONS#MAKEMJSPATHLOG"},"makeOriginalFlattenedConfigData":{"value":"Makes the original flattened config or variation data for a given config or variation provided.","key":"JSDOC#DEFINITIONS#MAKEORIGINALFLATTENEDCONFIGDATA"},"getComposedVariablesExclusivesFreeKeys":{"value":"Gets all Comment Variables keys from the data of a given variation (or config) that aren't marked to be exclusively used for composed variables.","key":"JSDOC#DEFINITIONS#GETCOMPOSEDVARIABLESEXCLUSIVESFREEKEYS"},"removeVariantPrefixFromVariationKey":{"value":"Removes the variant prefix of a Comment Variable key.","key":"JSDOC#DEFINITIONS#REMOVEVARIANTPREFIXFROMVARIATIONKEY"},"removeVariantPrefixFromVariationPlaceholder":{"value":"Removes the variant prefix of a Comment Variable placeholder.","key":"JSDOC#DEFINITIONS#REMOVEVARIANTPREFIXFROMVARIATIONPLACEHOLDER"},"surroundStringByOneSpace":{"value":"Surrounds a given string by one space right before and one space right after (`\" \"`).","key":"JSDOC#DEFINITIONS#SURROUNDSTRINGBYONESPACE"},"getArraySetDifference":{"value":"Computes the difference between two collections of strings efficiently.","key":"JSDOC#DEFINITIONS#GETARRAYSETDIFFERENCE"},"resolveCoreData":{"value":"Resolves the config's data into information consumable by the Comment Variables ecosystem.","key":"JSDOC#DEFINITIONS#RESOLVECOREDATA"},"resolveVariationData":{"value":"Resolves any provided variation data into information consumable by the Comment Variables ecosystem. Along with some tailored wiring, it follows the path of `resolveCoreData` while ignoring all of its checks, since they have already been passed in `resolveCoreData`.","key":"JSDOC#DEFINITIONS#RESOLVEVARIATIONDATA"}},"params":{"stringA":{"value":"The string.","key":"JSDOC#PARAMS#STRINGA"},"configDataA":{"value":"The config's data property or any provided variation data. (Values are typed `unknown` given the limitations in typing recursive values in JSDoc.)","key":"JSDOC#PARAMS#CONFIGDATAA"},"configDataC":{"value":"Any provided variation data or the config's data property. (Variation or config data at this time is still `unknown`.)","key":"JSDOC#PARAMS#CONFIGDATAC"},"configDataD":{"value":"The config's data property. (Config data at this time may still be `unknown`.)","key":"JSDOC#PARAMS#CONFIGDATAD"},"configDataE":{"value":"The config's data property or any provided variation data. (Config or variation data at this time is still `unknown`.)","key":"JSDOC#PARAMS#CONFIGDATAE"},"configDataF":{"value":"Any provided variation data. (Variation data at this time may still be `unknown`.)","key":"JSDOC#PARAMS#CONFIGDATAF"},"configDataMapOption":{"value":"The map housing the flattened keys with their values and sources through recursion, instantiated as a `new Map()`.","key":"JSDOC#PARAMS#CONFIGDATAMAPOPTION"},"parentKeysOption":{"value":"The list of keys that are parent to the key at hand given the recursive nature of the data's structure, instantiated as an empty array of strings (`[]`).","key":"JSDOC#PARAMS#PARENTKEYSOPTION"},"configPathA":{"value":"The path of the config from `comments.config.js`, or from a config passed via the `--config` flag in the CLI, or from one passed via `\"commentVariables.config\": \"my.config.js\"` in `.vscode/settings.json` for the VS Code extension.","key":"JSDOC#PARAMS#CONFIGPATHA"},"message":{"value":"The human-readable message of the error.","key":"JSDOC#PARAMS#MESSAGE"},"lintMessages":{"value":"The array of LintMessages such as obtained from an `ESLint` or a `Linter` instance running.","key":"JSDOC#PARAMS#LINTMESSAGES"},"pluginName":{"value":"The name of the plugin being used for filtering.","key":"JSDOC#PARAMS#PLUGINNAME"},"ruleName":{"value":"The name of the rule being used for filtering.","key":"JSDOC#PARAMS#RULENAME"},"options":{"value":"The additional options as follows:","key":"JSDOC#PARAMS#OPTIONS"},"settings":{"value":"The required settings as follows:","key":"JSDOC#PARAMS#SETTINGS"},"flattenedConfigDataA":{"value":"The provided flattened config data to be reversed.","key":"JSDOC#PARAMS#FLATTENEDCONFIGDATAA"},"composedVariable":{"value":"The composed variable as is.","key":"JSDOC#PARAMS#COMPOSEDVARIABLE"},"flattenedConfigDataB":{"value":"The flattened config data obtained from resolveConfig.","key":"JSDOC#PARAMS#FLATTENEDCONFIGDATAB"},"stringValue":{"value":"The encountered string value to be resolved.","key":"JSDOC#PARAMS#STRINGVALUE"},"aliases_flattenedKeys":{"value":"The aliases-to-flattened-keys dictionary obtained from resolveConfig.","key":"JSDOC#PARAMS#ALIASES_FLATTENEDKEYS"},"configDataB":{"value":"The original config data obtained from resolveConfig.","key":"JSDOC#PARAMS#CONFIGDATAB"},"callback":{"value":"The function that runs on every time a string value is encountered, set to `resolveConfigDataStringValue` by default.","key":"JSDOC#PARAMS#CALLBACK"},"resolveConfigResultsSuccessTrue":{"value":"The successful results of a `resolveConfig` operation, already vetted and ready to be transformed.","key":"JSDOC#PARAMS#RESOLVECONFIGRESULTSSUCCESSTRUE"},"moduleUrl":{"value":"The absolute path of the module to import.","key":"JSDOC#PARAMS#MODULEURL"},"resolvedConfigDataA":{"value":"The resolved config data.","key":"JSDOC#PARAMS#RESOLVEDCONFIGDATAA"},"parentKeys":{"value":"The list of keys that are parent to the key at hand given the recursive nature of the data's structure, instantiated as an empty array of strings (`[]`).","key":"JSDOC#PARAMS#PARENTKEYS"},"stringB":{"value":"The key part to be normalized, notably for variants.","key":"JSDOC#PARAMS#STRINGB"},"keys":{"value":"The list of keys at hand in order of traversal.","key":"JSDOC#PARAMS#KEYS"},"resolvedConfigDataB":{"value":"The resolved config data as obtained from `makeResolvedConfigData`.","key":"JSDOC#PARAMS#RESOLVEDCONFIGDATAB"},"jsonPath":{"value":"The expected `.json` path where the JSON resolved config data is to be written.","key":"JSDOC#PARAMS#JSONPATH"},"mjsPath":{"value":"The expected `.mjs` path where the MJS resolved config data is to be written.","key":"JSDOC#PARAMS#MJSPATH"},"composedVariablesExclusivesA":{"value":"The top-level list of all Comment Variables keys that are composed variables exclusives. (It is critical to list all variables only used to make composed variables in this array across all variations, so that they are ignored when comparing variations data keys to be one-to-one equivalents to canonical fallback data keys.)","key":"JSDOC#PARAMS#COMPOSEDVARIABLESEXCLUSIVESA"},"isVariationData":{"value":"A boolean that, when `false` or `undefined`, decides to crop out the initial variant parts of composed variables exclusives keys when addressing variation data. (Originally known as `isVariationData`, the argument remains since its logic is already implemented, even though a use case for core data as yet to be found.)","key":"JSDOC#PARAMS#ISVARIATIONDATA"},"variationKey":{"value":"The variation key that needs its variant prefix removed (such as going from `EN#COMMENT` to `COMMENT`).","key":"JSDOC#PARAMS#VARIATIONKEY"},"variationPlaceholder":{"value":"The variation placeholder that needs its variant prefix removed.","key":"JSDOC#PARAMS#VARIATIONPLACEHOLDER"},"stringC":{"value":"The given string to be surrounded.","key":"JSDOC#PARAMS#STRINGC"},"sourceA":{"value":"The source collection (uses `.array`).","key":"JSDOC#PARAMS#SOURCEA"},"exclusionB":{"value":"The exclusion collection (uses `.set`).","key":"JSDOC#PARAMS#EXCLUSIONB"},"extracts":{"value":"The array that holds all the object string values related to the config, since those are to be exclusively used with the config's data. Includes their file paths and `SourceLocation` objects alongside their values.","key":"JSDOC#PARAMS#EXTRACTS"},"composedVariablesExclusivesB":{"value":"The list of composed variable exclusives, which are Comment Variables keys, in order to ascertain their checks within `resolveCoreData`.","key":"JSDOC#PARAMS#COMPOSEDVARIABLESEXCLUSIVESB"},"core__originalFlattenedConfigData":{"value":"The `originalFlattenedConfigData` obtained from the previous `resolveCoreData` run, used to correctly branch the aliases from the core config data.","key":"JSDOC#PARAMS#CORE__ORIGINALFLATTENEDCONFIGDATA"},"core__aliases_flattenedKeys":{"value":"The `originalFlattenedConfigData` obtained from the previous `aliases_flattenedKeys` run, used to correctly resolve the composed variables segments aliases from the core config data.","key":"JSDOC#PARAMS#CORE__ALIASES_FLATTENEDKEYS"},"core__flattenedConfigData":{"value":"The `flattenedConfigData` obtained from the previous `resolveCoreData` run, used to correctly resolve the composed variables segments from the core config data.","key":"JSDOC#PARAMS#CORE__FLATTENEDCONFIGDATA"},"reference__flattenedConfigData":{"value":"The flattenedConfigData obtained from the previous resolveVariationData run, used when `allowIncompleteVariations` is set to `true` so that missing variation data can fallback to the reference data.","key":"JSDOC#PARAMS#REFERENCE__FLATTENEDCONFIGDATA"}},"returns":{"escapeRegex":{"value":"The string with regex characters escaped.","key":"JSDOC#RETURNS#ESCAPEREGEX"},"makeIsolatedStringRegex":{"value":"The regex complete with positive lookbehind and positive lookahead to ensure the string is taken into account only when surrounded by whitespace.","key":"JSDOC#RETURNS#MAKEISOLATEDSTRINGREGEX"},"flattenConfigData":{"value":"The flattened config or variation data in a success object (`success: true`). (The strict reversibility of the `resolve` and `compress` commands is handled afterwards.) Errors are bubbled up during failures so they can be reused differently on the CLI and the VS Code extension in a failure object (`success: false`).","key":"JSDOC#RETURNS#FLATTENCONFIGDATA"},"resolveConfig":{"value":"The flattened config data, the reverse flattened config data, the verified config path, the raw passed ignores, the original config, and more. Errors are returned during failures so they can be reused differently on the CLI and the VS Code extension.","key":"JSDOC#RETURNS#RESOLVECONFIG"},"makeSuccessFalseTypeError":{"value":"A `{success: false}` object with a single error in its error array of `{type: \"error\"}`.","key":"JSDOC#RETURNS#MAKESUCCESSFALSETYPEERROR"},"extractValueLocationsFromLintMessages":{"value":"An array of Value Locations with the value, the file path and the SourceLocation (LOC) included for each.","key":"JSDOC#RETURNS#EXTRACTVALUELOCATIONSFROMLINTMESSAGES"},"reverseFlattenedConfigData":{"value":"The reversed version of the provided config data.","key":"JSDOC#RETURNS#REVERSEFLATTENEDCONFIGDATA"},"resolveComposedVariable":{"value":"The resolved composed variable as a single natural string.","key":"JSDOC#RETURNS#RESOLVECOMPOSEDVARIABLE"},"resolveConfigDataStringValue":{"value":"The string value resolved as the relevant Comment Variable that it is.","key":"JSDOC#RETURNS#RESOLVECONFIGDATASTRINGVALUE"},"resolveConfigData":{"value":"Just the resolved config data if successful, or an object with `success: false` and errors if unsuccessful.","key":"JSDOC#RETURNS#RESOLVECONFIGDATA"},"makeResolvedConfigData":{"value":"An object with `success: true` and the resolved config data if successful, or with `success: false` and errors if unsuccessful.","key":"JSDOC#RETURNS#MAKERESOLVEDCONFIGDATA"},"freshImport":{"value":"Either an object with its `default` property sets to the default export of the module successfully loaded or `null` when an error arises. (Debugging is currently manual by looking at the error being caught in the child process.)","key":"JSDOC#RETURNS#FRESHIMPORT"},"transformResolvedConfigData":{"value":"The transformed resolved config data with keys and placeholders readily accessible alongside values.","key":"JSDOC#RETURNS#TRANSFORMRESOLVEDCONFIGDATA"},"normalize":{"value":"The normalized key part under a common algorith for the entire library.","key":"JSDOC#RETURNS#NORMALIZE"},"makeNormalizedKey":{"value":"The normalized key of a Comment Variable.","key":"JSDOC#RETURNS#MAKENORMALIZEDKEY"},"makeJsonData":{"value":"The JSON resolved config data to be written at an expected `.json` path. It can be consumed by any language that can parse JSON, which means virtually all modern languages, so that Comment Variables can act as a single source of truth for text variables beyond JavaScript and TypeScript.","key":"JSDOC#RETURNS#MAKEJSONDATA"},"makeMjsData":{"value":"The MJS resolved config data to be written at an expected `.mjs` path. Its format makes it possible to be consumed with literal type safety in both JavaScript and TypeScript.","key":"JSDOC#RETURNS#MAKEMJSDATA"},"makeJsonPathLog":{"value":"The log that announces the writing of the JSON resolved config data has been completed.","key":"JSDOC#RETURNS#MAKEJSONPATHLOG"},"makeMjsPathLog":{"value":"The log that announces the writing of the MJS resolved config data has been completed.","key":"JSDOC#RETURNS#MAKEMJSPATHLOG"},"makeOriginalFlattenedConfigData":{"value":"The original flattened config or variation data at the key `originalFlattenedConfigData` along with the verified original config or variation data at the key `configDataResultsData`.","key":"JSDOC#RETURNS#MAKEORIGINALFLATTENEDCONFIGDATA"},"getComposedVariablesExclusivesFreeKeys":{"value":"All Comment Variables keys from the data of a given variation (or config) that aren't marked to be exclusively used for composed variables. This is to later ensure that all variations share the exact same utilized keys for perfect versatility.","key":"JSDOC#RETURNS#GETCOMPOSEDVARIABLESEXCLUSIVESFREEKEYS"},"removeVariantPrefixFromVariationKey":{"value":"The variation key with its variant prefix removed, akin to a Comment Variable key when `variations` are not in use.","key":"JSDOC#RETURNS#REMOVEVARIANTPREFIXFROMVARIATIONKEY"},"removeVariantPrefixFromVariationPlaceholder":{"value":"The variation placeholder with its variant prefix removed, akin to a Comment Variable placeholder when `variations` are not in use.","key":"JSDOC#RETURNS#REMOVEVARIANTPREFIXFROMVARIATIONPLACEHOLDER"},"surroundStringByOneSpace":{"value":"The given string surrounded by one space.","key":"JSDOC#RETURNS#SURROUNDSTRINGBYONESPACE"},"getArraySetDifference":{"value":"A new `Set` containing all elements in `a` that are not in `b`.","key":"JSDOC#RETURNS#GETARRAYSETDIFFERENCE"},"resolveCoreData":{"value":"With a `{success: true}` object, all the information to be consumed by the Comment Variables CLI and the Comment Variables VS Code extension, namingly `originalFlattenedConfigData`, `aliases_flattenedKeys`, `flattenedConfigData`, `reversedFlattenedConfigData`, `keys_valueLocations`, `nonAliasesKeys_valueLocations`, `aliasesKeys_valueLocations`, `configDataResultsData`, and probably more as the function evolves.","key":"JSDOC#RETURNS#RESOLVECOREDATA"},"resolveVariationData":{"value":"With a `{success: true}` object, the given variation's own information to be consumed by the Comment Variables CLI and the Comment Variables VS Code extension, namingly its own `originalFlattenedConfigData`, its own `aliases_flattenedKeys`, its own `flattenedConfigData`, its own `reversedFlattenedConfigData`, and accessorily its own `configDataResultsData`.","key":"JSDOC#RETURNS#RESOLVEVARIATIONDATA"}},"constants":{"configKeyRegex":{"value":"Ensures keys should only include lowercase letters (`Ll`), uppercase letters (`Lu`), other letters (`Lo`), dash punctuation (`Pd`), connector punctuation (`Pc`), numbers (`N`) and whitespaces (`s`).","key":"JSDOC#CONSTANTS#CONFIGKEYREGEX"},"flattenedConfigKeyRegex":{"value":"Same as `configKeyRegex` but without lowercase letters (`\\p{Ll}`), wthout dash punctuation (`Pd`), connector punctuation (`Pc`), whitespaces (`\\s`), which all three are replaced by underscores (`_`), and with the '`#`' character (that links each subkey together).","key":"JSDOC#CONSTANTS#FLATTENEDCONFIGKEYREGEX"},"flattenedConfigPlaceholderLocalRegex":{"value":"Same as `flattenedConfigKeyRegex` but taking the prefix `$COMMENT` and its `#` into consideration, preventing two consecutive `#`'s, removing `^` and `$` in the capture group, and using `_` as replacement for whitespaces.","key":"JSDOC#CONSTANTS#FLATTENEDCONFIGPLACEHOLDERLOCALREGEX"},"flattenedConfigPlaceholderGlobalRegex":{"value":"Same as `flattenedConfigPlaceholderLocalRegex` but globally.","key":"JSDOC#CONSTANTS#FLATTENEDCONFIGPLACEHOLDERGLOBALREGEX"},"extractRuleConfigData":{"value":"The core data needed to run the \"extract\" rule, fully-named `\"extract-object-string-literal-values\"`. (The name of the object could eventually be changed for being too function-sounding, since it could be confused for \"a function that extract rule config data\" instead of what it is, \"the data of the extract rule config\".)","key":"JSDOC#CONSTANTS#EXTRACTRULECONFIGDATA"}}},"forComposedVariables":{"pluginName":{"value":"plugin","key":"FORCOMPOSEDVARIABLES#PLUGINNAME"},"ruleName":{"value":"rule","key":"FORCOMPOSEDVARIABLES#RULENAME"},"theNameOf":{"value":"The name of the","key":"FORCOMPOSEDVARIABLES#THENAMEOF"},"forFilteringPeriod":{"value":"being used for filtering.","key":"FORCOMPOSEDVARIABLES#FORFILTERINGPERIOD"},"flattenedConfigDataB":{"value":"The flattened config data","key":"FORCOMPOSEDVARIABLES#FLATTENEDCONFIGDATAB"},"aliases_flattenedKeys":{"value":"The aliases-to-flattened-keys dictionary","key":"FORCOMPOSEDVARIABLES#ALIASES_FLATTENEDKEYS"},"configDataB":{"value":"The original config data","key":"FORCOMPOSEDVARIABLES#CONFIGDATAB"},"obtainedResolveConfig":{"value":"obtained from resolveConfig.","key":"FORCOMPOSEDVARIABLES#OBTAINEDRESOLVECONFIG"},"recursivelyResolvesTo":{"value":"Recursively resolves Comment Variables config data values (being strings or nested objects) to generate an","key":"FORCOMPOSEDVARIABLES#RECURSIVELYRESOLVESTO"},"createsThat":{"value":"Creates that","key":"FORCOMPOSEDVARIABLES#CREATESTHAT"},"objectConfigData":{"value":"object with the same keys and the same shape as the original config data now with all string values entirely resolved.","key":"FORCOMPOSEDVARIABLES#OBJECTCONFIGDATA"},"transformedObjectConfigData":{"value":"object with the same keys and the same base shape as the original config data now with all string values entirely resolved alongside Comment Variables keys.","key":"FORCOMPOSEDVARIABLES#TRANSFORMEDOBJECTCONFIGDATA"},"makesThe":{"value":"Makes the","key":"FORCOMPOSEDVARIABLES#MAKESTHE"},"resolvedAnExpected":{"value":"resolved config data to be written at an expected","key":"FORCOMPOSEDVARIABLES#RESOLVEDANEXPECTED"},"pathPeriod":{"value":" path.","key":"FORCOMPOSEDVARIABLES#PATHPERIOD"},"jsonCaps":{"value":"JSON","key":"FORCOMPOSEDVARIABLES#JSONCAPS"},"dotJsonPathPeriod":{"value":"`.json` path.","key":"FORCOMPOSEDVARIABLES#DOTJSONPATHPERIOD"},"mjsCaps":{"value":"MJS","key":"FORCOMPOSEDVARIABLES#MJSCAPS"},"dotMjsPathPeriod":{"value":"`.mjs` path.","key":"FORCOMPOSEDVARIABLES#DOTMJSPATHPERIOD"},"logWritingOfThe":{"value":"log that announces the writing of the","key":"FORCOMPOSEDVARIABLES#LOGWRITINGOFTHE"},"resolvedConfigDataPeriod":{"value":"resolved config data.","key":"FORCOMPOSEDVARIABLES#RESOLVEDCONFIGDATAPERIOD"},"_The":{"value":"The","key":"FORCOMPOSEDVARIABLES#_THE"},"expected":{"value":"expected","key":"FORCOMPOSEDVARIABLES#EXPECTED"},"dotJsonPath":{"value":"`.json` path","key":"FORCOMPOSEDVARIABLES#DOTJSONPATH"},"dotMjsPath":{"value":"`.mjs` path","key":"FORCOMPOSEDVARIABLES#DOTMJSPATH"},"whereThe":{"value":"where the","key":"FORCOMPOSEDVARIABLES#WHERETHE"},"resolvedToBeWritten":{"value":"resolved config data is to be written.","key":"FORCOMPOSEDVARIABLES#RESOLVEDTOBEWRITTEN"},"makeJsonDataReturns":{"value":"It can be consumed by any language that can parse JSON, which means virtually all modern languages, so that Comment Variables can act as a single source of truth for text variables beyond JavaScript and TypeScript.","key":"FORCOMPOSEDVARIABLES#MAKEJSONDATARETURNS"},"makeMjsDataReturns":{"value":"Its format makes it possible to be consumed with literal type safety in both JavaScript and TypeScript.","key":"FORCOMPOSEDVARIABLES#MAKEMJSDATARETURNS"},"resolvedConfigCompleted":{"value":"resolved config data has been completed.","key":"FORCOMPOSEDVARIABLES#RESOLVEDCONFIGCOMPLETED"},"configData":{"value":"The config's data property.","key":"FORCOMPOSEDVARIABLES#CONFIGDATA"},"variationData":{"value":"Any provided variation data.","key":"FORCOMPOSEDVARIABLES#VARIATIONDATA"},"configOrVariationData":{"value":"The config's data property or any provided variation data.","key":"FORCOMPOSEDVARIABLES#CONFIGORVARIATIONDATA"},"variationOrConfigData":{"value":"Any provided variation data or the config's data property.","key":"FORCOMPOSEDVARIABLES#VARIATIONORCONFIGDATA"},"configDataA":{"value":"(Values are typed `unknown` given the limitations in typing recursive values in JSDoc.)","key":"FORCOMPOSEDVARIABLES#CONFIGDATAA"},"configDataC":{"value":"(Config data at this time is still `unknown`.)","key":"FORCOMPOSEDVARIABLES#CONFIGDATAC"},"configDataD":{"value":"(Config data at this time may still be `unknown`.)","key":"FORCOMPOSEDVARIABLES#CONFIGDATAD"},"variationDataC":{"value":"(Variation data at this time is still `unknown`.)","key":"FORCOMPOSEDVARIABLES#VARIATIONDATAC"},"variationDataD":{"value":"(Variation data at this time may still be `unknown`.)","key":"FORCOMPOSEDVARIABLES#VARIATIONDATAD"},"configOrVariationDataC":{"value":"(Config or variation data at this time is still `unknown`.)","key":"FORCOMPOSEDVARIABLES#CONFIGORVARIATIONDATAC"},"configOrVariationDataD":{"value":"(Config or variation data at this time may still be `unknown`.)","key":"FORCOMPOSEDVARIABLES#CONFIGORVARIATIONDATAD"},"variationOrConfigDataC":{"value":"(Variation – or config – data at this time is still `unknown`.)","key":"FORCOMPOSEDVARIABLES#VARIATIONORCONFIGDATAC"},"variationOrConfigDataD":{"value":"(Variation – or config – data at this time may still be `unknown`.)","key":"FORCOMPOSEDVARIABLES#VARIATIONORCONFIGDATAD"},"__configData":{"value":"(Config data","key":"FORCOMPOSEDVARIABLES#__CONFIGDATA"},"__variationData":{"value":"(Variation data","key":"FORCOMPOSEDVARIABLES#__VARIATIONDATA"},"__configOrVariationData":{"value":"(Config or variation data","key":"FORCOMPOSEDVARIABLES#__CONFIGORVARIATIONDATA"},"__variationOrConfigData":{"value":"(Variation or config data","key":"FORCOMPOSEDVARIABLES#__VARIATIONORCONFIGDATA"},"atThisTime":{"value":"at this time","key":"FORCOMPOSEDVARIABLES#ATTHISTIME"},"isStillUnknown__":{"value":"is still `unknown`.)","key":"FORCOMPOSEDVARIABLES#ISSTILLUNKNOWN__"},"mayStillUnknown__":{"value":"may still be `unknown`.)","key":"FORCOMPOSEDVARIABLES#MAYSTILLUNKNOWN__"}}} */ ({
  "jsDoc": {
    "definitions": {
      "escapeRegex": {
        "value": "Escapes all regex characters with a `\"\\\"` in a string to prepare it for use in a regex.",
        "key": "JSDOC#DEFINITIONS#ESCAPEREGEX"
      },
      "makeIsolatedStringRegex": {
        "value": "Makes a global regex for a given string that ensures it is surrounded by whitespace.",
        "key": "JSDOC#DEFINITIONS#MAKEISOLATEDSTRINGREGEX"
      },
      "flattenConfigData": {
        "value": "Flattens the config's data property into a one-dimensional object of `COMMENT#COMMENT`-like keys and string values. (This function is now also used to flatten variation data.)",
        "key": "JSDOC#DEFINITIONS#FLATTENCONFIGDATA"
      },
      "resolveConfig": {
        "value": "Verifies, validates and resolves the config path to retrieve the config's data, ignores, and more.",
        "key": "JSDOC#DEFINITIONS#RESOLVECONFIG"
      },
      "makeSuccessFalseTypeError": {
        "value": "Makes a `{success: false}` object with a single error in its errors array of `{type: \"error\"}` based on the message it is meant to display.",
        "key": "JSDOC#DEFINITIONS#MAKESUCCESSFALSETYPEERROR"
      },
      "extractValueLocationsFromLintMessages": {
        "value": "Extracts and format the output JSON from an ESLint rule's `context.report` to turn it into Value Locations.",
        "key": "JSDOC#DEFINITIONS#EXTRACTVALUELOCATIONSFROMLINTMESSAGES"
      },
      "reverseFlattenedConfigData": {
        "value": "Reverses the keys and the values of a flattened config data object.",
        "key": "JSDOC#DEFINITIONS#REVERSEFLATTENEDCONFIGDATA"
      },
      "resolveComposedVariable": {
        "value": "Resolves a composed variable, as in a string made of several comment variables, to the actual Comment Variable it is meant to represent.",
        "key": "JSDOC#DEFINITIONS#RESOLVECOMPOSEDVARIABLE"
      },
      "resolveConfigDataStringValue": {
        "value": "Resolves a string value from Comment Variables config data taking into account the possibility that it is first an alias variable, second (and on the alias route) a composed variable, third (also on the alias route) a comment variable.",
        "key": "JSDOC#DEFINITIONS#RESOLVECONFIGDATASTRINGVALUE"
      },
      "resolveConfigData": {
        "value": "Recursively resolves Comment Variables config data values (being strings or nested objects) to generate an object with the same keys and the same shape as the original config data now with all string values entirely resolved.",
        "key": "JSDOC#DEFINITIONS#RESOLVECONFIGDATA"
      },
      "makeResolvedConfigData": {
        "value": "Creates that object with the same keys and the same base shape as the original config data now with all string values entirely resolved alongside Comment Variables keys.",
        "key": "JSDOC#DEFINITIONS#MAKERESOLVEDCONFIGDATA"
      },
      "freshImport": {
        "value": "Guarantees a fresh import of the config, negating the innate (and hidden) cache of the dynamic `import` utility.",
        "key": "JSDOC#DEFINITIONS#FRESHIMPORT"
      },
      "transformResolvedConfigData": {
        "value": "Transforms resolved config data with keys alongside values.",
        "key": "JSDOC#DEFINITIONS#TRANSFORMRESOLVEDCONFIGDATA"
      },
      "normalize": {
        "value": "Normalizes a Comment Variables key part.",
        "key": "JSDOC#DEFINITIONS#NORMALIZE"
      },
      "makeNormalizedKey": {
        "value": "Normalizes and makes a Comment Variable key from the list of keys that trace to its value.",
        "key": "JSDOC#DEFINITIONS#MAKENORMALIZEDKEY"
      },
      "makeJsonData": {
        "value": "Makes the JSON resolved config data to be written at an expected `.json` path.",
        "key": "JSDOC#DEFINITIONS#MAKEJSONDATA"
      },
      "makeMjsData": {
        "value": "Makes the MJS resolved config data to be written at an expected `.mjs` path.",
        "key": "JSDOC#DEFINITIONS#MAKEMJSDATA"
      },
      "makeJsonPathLog": {
        "value": "Makes the log that announces the writing of the JSON resolved config data.",
        "key": "JSDOC#DEFINITIONS#MAKEJSONPATHLOG"
      },
      "makeMjsPathLog": {
        "value": "Makes the log that announces the writing of the MJS resolved config data.",
        "key": "JSDOC#DEFINITIONS#MAKEMJSPATHLOG"
      },
      "makeOriginalFlattenedConfigData": {
        "value": "Makes the original flattened config or variation data for a given config or variation provided.",
        "key": "JSDOC#DEFINITIONS#MAKEORIGINALFLATTENEDCONFIGDATA"
      },
      "getComposedVariablesExclusivesFreeKeys": {
        "value": "Gets all Comment Variables keys from the data of a given variation (or config) that aren't marked to be exclusively used for composed variables.",
        "key": "JSDOC#DEFINITIONS#GETCOMPOSEDVARIABLESEXCLUSIVESFREEKEYS"
      },
      "removeVariantPrefixFromVariationKey": {
        "value": "Removes the variant prefix of a Comment Variable key.",
        "key": "JSDOC#DEFINITIONS#REMOVEVARIANTPREFIXFROMVARIATIONKEY"
      },
      "removeVariantPrefixFromVariationPlaceholder": {
        "value": "Removes the variant prefix of a Comment Variable placeholder.",
        "key": "JSDOC#DEFINITIONS#REMOVEVARIANTPREFIXFROMVARIATIONPLACEHOLDER"
      },
      "surroundStringByOneSpace": {
        "value": "Surrounds a given string by one space right before and one space right after (`\" \"`).",
        "key": "JSDOC#DEFINITIONS#SURROUNDSTRINGBYONESPACE"
      },
      "getArraySetDifference": {
        "value": "Computes the difference between two collections of strings efficiently.",
        "key": "JSDOC#DEFINITIONS#GETARRAYSETDIFFERENCE"
      },
      "resolveCoreData": {
        "value": "Resolves the config's data into information consumable by the Comment Variables ecosystem.",
        "key": "JSDOC#DEFINITIONS#RESOLVECOREDATA"
      },
      "resolveVariationData": {
        "value": "Resolves any provided variation data into information consumable by the Comment Variables ecosystem. Along with some tailored wiring, it follows the path of `resolveCoreData` while ignoring all of its checks, since they have already been passed in `resolveCoreData`.",
        "key": "JSDOC#DEFINITIONS#RESOLVEVARIATIONDATA"
      }
    },
    "params": {
      "stringA": {
        "value": "The string.",
        "key": "JSDOC#PARAMS#STRINGA"
      },
      "configDataA": {
        "value": "The config's data property or any provided variation data. (Values are typed `unknown` given the limitations in typing recursive values in JSDoc.)",
        "key": "JSDOC#PARAMS#CONFIGDATAA"
      },
      "configDataC": {
        "value": "Any provided variation data or the config's data property. (Variation or config data at this time is still `unknown`.)",
        "key": "JSDOC#PARAMS#CONFIGDATAC"
      },
      "configDataD": {
        "value": "The config's data property. (Config data at this time may still be `unknown`.)",
        "key": "JSDOC#PARAMS#CONFIGDATAD"
      },
      "configDataE": {
        "value": "The config's data property or any provided variation data. (Config or variation data at this time is still `unknown`.)",
        "key": "JSDOC#PARAMS#CONFIGDATAE"
      },
      "configDataF": {
        "value": "Any provided variation data. (Variation data at this time may still be `unknown`.)",
        "key": "JSDOC#PARAMS#CONFIGDATAF"
      },
      "configDataMapOption": {
        "value": "The map housing the flattened keys with their values and sources through recursion, instantiated as a `new Map()`.",
        "key": "JSDOC#PARAMS#CONFIGDATAMAPOPTION"
      },
      "parentKeysOption": {
        "value": "The list of keys that are parent to the key at hand given the recursive nature of the data's structure, instantiated as an empty array of strings (`[]`).",
        "key": "JSDOC#PARAMS#PARENTKEYSOPTION"
      },
      "configPathA": {
        "value": "The path of the config from `comments.config.js`, or from a config passed via the `--config` flag in the CLI, or from one passed via `\"commentVariables.config\": \"my.config.js\"` in `.vscode/settings.json` for the VS Code extension.",
        "key": "JSDOC#PARAMS#CONFIGPATHA"
      },
      "message": {
        "value": "The human-readable message of the error.",
        "key": "JSDOC#PARAMS#MESSAGE"
      },
      "lintMessages": {
        "value": "The array of LintMessages such as obtained from an `ESLint` or a `Linter` instance running.",
        "key": "JSDOC#PARAMS#LINTMESSAGES"
      },
      "pluginName": {
        "value": "The name of the plugin being used for filtering.",
        "key": "JSDOC#PARAMS#PLUGINNAME"
      },
      "ruleName": {
        "value": "The name of the rule being used for filtering.",
        "key": "JSDOC#PARAMS#RULENAME"
      },
      "options": {
        "value": "The additional options as follows:",
        "key": "JSDOC#PARAMS#OPTIONS"
      },
      "settings": {
        "value": "The required settings as follows:",
        "key": "JSDOC#PARAMS#SETTINGS"
      },
      "flattenedConfigDataA": {
        "value": "The provided flattened config data to be reversed.",
        "key": "JSDOC#PARAMS#FLATTENEDCONFIGDATAA"
      },
      "composedVariable": {
        "value": "The composed variable as is.",
        "key": "JSDOC#PARAMS#COMPOSEDVARIABLE"
      },
      "flattenedConfigDataB": {
        "value": "The flattened config data obtained from resolveConfig.",
        "key": "JSDOC#PARAMS#FLATTENEDCONFIGDATAB"
      },
      "stringValue": {
        "value": "The encountered string value to be resolved.",
        "key": "JSDOC#PARAMS#STRINGVALUE"
      },
      "aliases_flattenedKeys": {
        "value": "The aliases-to-flattened-keys dictionary obtained from resolveConfig.",
        "key": "JSDOC#PARAMS#ALIASES_FLATTENEDKEYS"
      },
      "configDataB": {
        "value": "The original config data obtained from resolveConfig.",
        "key": "JSDOC#PARAMS#CONFIGDATAB"
      },
      "callback": {
        "value": "The function that runs on every time a string value is encountered, set to `resolveConfigDataStringValue` by default.",
        "key": "JSDOC#PARAMS#CALLBACK"
      },
      "resolveConfigResultsSuccessTrue": {
        "value": "The successful results of a `resolveConfig` operation, already vetted and ready to be transformed.",
        "key": "JSDOC#PARAMS#RESOLVECONFIGRESULTSSUCCESSTRUE"
      },
      "moduleUrl": {
        "value": "The absolute path of the module to import.",
        "key": "JSDOC#PARAMS#MODULEURL"
      },
      "resolvedConfigDataA": {
        "value": "The resolved config data.",
        "key": "JSDOC#PARAMS#RESOLVEDCONFIGDATAA"
      },
      "parentKeys": {
        "value": "The list of keys that are parent to the key at hand given the recursive nature of the data's structure, instantiated as an empty array of strings (`[]`).",
        "key": "JSDOC#PARAMS#PARENTKEYS"
      },
      "stringB": {
        "value": "The key part to be normalized, notably for variants.",
        "key": "JSDOC#PARAMS#STRINGB"
      },
      "keys": {
        "value": "The list of keys at hand in order of traversal.",
        "key": "JSDOC#PARAMS#KEYS"
      },
      "resolvedConfigDataB": {
        "value": "The resolved config data as obtained from `makeResolvedConfigData`.",
        "key": "JSDOC#PARAMS#RESOLVEDCONFIGDATAB"
      },
      "jsonPath": {
        "value": "The expected `.json` path where the JSON resolved config data is to be written.",
        "key": "JSDOC#PARAMS#JSONPATH"
      },
      "mjsPath": {
        "value": "The expected `.mjs` path where the MJS resolved config data is to be written.",
        "key": "JSDOC#PARAMS#MJSPATH"
      },
      "composedVariablesExclusivesA": {
        "value": "The top-level list of all Comment Variables keys that are composed variables exclusives. (It is critical to list all variables only used to make composed variables in this array across all variations, so that they are ignored when comparing variations data keys to be one-to-one equivalents to canonical fallback data keys.)",
        "key": "JSDOC#PARAMS#COMPOSEDVARIABLESEXCLUSIVESA"
      },
      "isVariationData": {
        "value": "A boolean that, when `false` or `undefined`, decides to crop out the initial variant parts of composed variables exclusives keys when addressing variation data. (Originally known as `isVariationData`, the argument remains since its logic is already implemented, even though a use case for core data as yet to be found.)",
        "key": "JSDOC#PARAMS#ISVARIATIONDATA"
      },
      "variationKey": {
        "value": "The variation key that needs its variant prefix removed (such as going from `EN#COMMENT` to `COMMENT`).",
        "key": "JSDOC#PARAMS#VARIATIONKEY"
      },
      "variationPlaceholder": {
        "value": "The variation placeholder that needs its variant prefix removed.",
        "key": "JSDOC#PARAMS#VARIATIONPLACEHOLDER"
      },
      "stringC": {
        "value": "The given string to be surrounded.",
        "key": "JSDOC#PARAMS#STRINGC"
      },
      "sourceA": {
        "value": "The source collection (uses `.array`).",
        "key": "JSDOC#PARAMS#SOURCEA"
      },
      "exclusionB": {
        "value": "The exclusion collection (uses `.set`).",
        "key": "JSDOC#PARAMS#EXCLUSIONB"
      },
      "extracts": {
        "value": "The array that holds all the object string values related to the config, since those are to be exclusively used with the config's data. Includes their file paths and `SourceLocation` objects alongside their values.",
        "key": "JSDOC#PARAMS#EXTRACTS"
      },
      "composedVariablesExclusivesB": {
        "value": "The list of composed variable exclusives, which are Comment Variables keys, in order to ascertain their checks within `resolveCoreData`.",
        "key": "JSDOC#PARAMS#COMPOSEDVARIABLESEXCLUSIVESB"
      },
      "core__originalFlattenedConfigData": {
        "value": "The `originalFlattenedConfigData` obtained from the previous `resolveCoreData` run, used to correctly branch the aliases from the core config data.",
        "key": "JSDOC#PARAMS#CORE__ORIGINALFLATTENEDCONFIGDATA"
      },
      "core__aliases_flattenedKeys": {
        "value": "The `originalFlattenedConfigData` obtained from the previous `aliases_flattenedKeys` run, used to correctly resolve the composed variables segments aliases from the core config data.",
        "key": "JSDOC#PARAMS#CORE__ALIASES_FLATTENEDKEYS"
      },
      "core__flattenedConfigData": {
        "value": "The `flattenedConfigData` obtained from the previous `resolveCoreData` run, used to correctly resolve the composed variables segments from the core config data.",
        "key": "JSDOC#PARAMS#CORE__FLATTENEDCONFIGDATA"
      },
      "reference__flattenedConfigData": {
        "value": "The flattenedConfigData obtained from the previous resolveVariationData run, used when `allowIncompleteVariations` is set to `true` so that missing variation data can fallback to the reference data.",
        "key": "JSDOC#PARAMS#REFERENCE__FLATTENEDCONFIGDATA"
      }
    },
    "returns": {
      "escapeRegex": {
        "value": "The string with regex characters escaped.",
        "key": "JSDOC#RETURNS#ESCAPEREGEX"
      },
      "makeIsolatedStringRegex": {
        "value": "The regex complete with positive lookbehind and positive lookahead to ensure the string is taken into account only when surrounded by whitespace.",
        "key": "JSDOC#RETURNS#MAKEISOLATEDSTRINGREGEX"
      },
      "flattenConfigData": {
        "value": "The flattened config or variation data in a success object (`success: true`). (The strict reversibility of the `resolve` and `compress` commands is handled afterwards.) Errors are bubbled up during failures so they can be reused differently on the CLI and the VS Code extension in a failure object (`success: false`).",
        "key": "JSDOC#RETURNS#FLATTENCONFIGDATA"
      },
      "resolveConfig": {
        "value": "The flattened config data, the reverse flattened config data, the verified config path, the raw passed ignores, the original config, and more. Errors are returned during failures so they can be reused differently on the CLI and the VS Code extension.",
        "key": "JSDOC#RETURNS#RESOLVECONFIG"
      },
      "makeSuccessFalseTypeError": {
        "value": "A `{success: false}` object with a single error in its error array of `{type: \"error\"}`.",
        "key": "JSDOC#RETURNS#MAKESUCCESSFALSETYPEERROR"
      },
      "extractValueLocationsFromLintMessages": {
        "value": "An array of Value Locations with the value, the file path and the SourceLocation (LOC) included for each.",
        "key": "JSDOC#RETURNS#EXTRACTVALUELOCATIONSFROMLINTMESSAGES"
      },
      "reverseFlattenedConfigData": {
        "value": "The reversed version of the provided config data.",
        "key": "JSDOC#RETURNS#REVERSEFLATTENEDCONFIGDATA"
      },
      "resolveComposedVariable": {
        "value": "The resolved composed variable as a single natural string.",
        "key": "JSDOC#RETURNS#RESOLVECOMPOSEDVARIABLE"
      },
      "resolveConfigDataStringValue": {
        "value": "The string value resolved as the relevant Comment Variable that it is.",
        "key": "JSDOC#RETURNS#RESOLVECONFIGDATASTRINGVALUE"
      },
      "resolveConfigData": {
        "value": "Just the resolved config data if successful, or an object with `success: false` and errors if unsuccessful.",
        "key": "JSDOC#RETURNS#RESOLVECONFIGDATA"
      },
      "makeResolvedConfigData": {
        "value": "An object with `success: true` and the resolved config data if successful, or with `success: false` and errors if unsuccessful.",
        "key": "JSDOC#RETURNS#MAKERESOLVEDCONFIGDATA"
      },
      "freshImport": {
        "value": "Either an object with its `default` property sets to the default export of the module successfully loaded or `null` when an error arises. (Debugging is currently manual by looking at the error being caught in the child process.)",
        "key": "JSDOC#RETURNS#FRESHIMPORT"
      },
      "transformResolvedConfigData": {
        "value": "The transformed resolved config data with keys and placeholders readily accessible alongside values.",
        "key": "JSDOC#RETURNS#TRANSFORMRESOLVEDCONFIGDATA"
      },
      "normalize": {
        "value": "The normalized key part under a common algorith for the entire library.",
        "key": "JSDOC#RETURNS#NORMALIZE"
      },
      "makeNormalizedKey": {
        "value": "The normalized key of a Comment Variable.",
        "key": "JSDOC#RETURNS#MAKENORMALIZEDKEY"
      },
      "makeJsonData": {
        "value": "The JSON resolved config data to be written at an expected `.json` path. It can be consumed by any language that can parse JSON, which means virtually all modern languages, so that Comment Variables can act as a single source of truth for text variables beyond JavaScript and TypeScript.",
        "key": "JSDOC#RETURNS#MAKEJSONDATA"
      },
      "makeMjsData": {
        "value": "The MJS resolved config data to be written at an expected `.mjs` path. Its format makes it possible to be consumed with literal type safety in both JavaScript and TypeScript.",
        "key": "JSDOC#RETURNS#MAKEMJSDATA"
      },
      "makeJsonPathLog": {
        "value": "The log that announces the writing of the JSON resolved config data has been completed.",
        "key": "JSDOC#RETURNS#MAKEJSONPATHLOG"
      },
      "makeMjsPathLog": {
        "value": "The log that announces the writing of the MJS resolved config data has been completed.",
        "key": "JSDOC#RETURNS#MAKEMJSPATHLOG"
      },
      "makeOriginalFlattenedConfigData": {
        "value": "The original flattened config or variation data at the key `originalFlattenedConfigData` along with the verified original config or variation data at the key `configDataResultsData`.",
        "key": "JSDOC#RETURNS#MAKEORIGINALFLATTENEDCONFIGDATA"
      },
      "getComposedVariablesExclusivesFreeKeys": {
        "value": "All Comment Variables keys from the data of a given variation (or config) that aren't marked to be exclusively used for composed variables. This is to later ensure that all variations share the exact same utilized keys for perfect versatility.",
        "key": "JSDOC#RETURNS#GETCOMPOSEDVARIABLESEXCLUSIVESFREEKEYS"
      },
      "removeVariantPrefixFromVariationKey": {
        "value": "The variation key with its variant prefix removed, akin to a Comment Variable key when `variations` are not in use.",
        "key": "JSDOC#RETURNS#REMOVEVARIANTPREFIXFROMVARIATIONKEY"
      },
      "removeVariantPrefixFromVariationPlaceholder": {
        "value": "The variation placeholder with its variant prefix removed, akin to a Comment Variable placeholder when `variations` are not in use.",
        "key": "JSDOC#RETURNS#REMOVEVARIANTPREFIXFROMVARIATIONPLACEHOLDER"
      },
      "surroundStringByOneSpace": {
        "value": "The given string surrounded by one space.",
        "key": "JSDOC#RETURNS#SURROUNDSTRINGBYONESPACE"
      },
      "getArraySetDifference": {
        "value": "A new `Set` containing all elements in `a` that are not in `b`.",
        "key": "JSDOC#RETURNS#GETARRAYSETDIFFERENCE"
      },
      "resolveCoreData": {
        "value": "With a `{success: true}` object, all the information to be consumed by the Comment Variables CLI and the Comment Variables VS Code extension, namingly `originalFlattenedConfigData`, `aliases_flattenedKeys`, `flattenedConfigData`, `reversedFlattenedConfigData`, `keys_valueLocations`, `nonAliasesKeys_valueLocations`, `aliasesKeys_valueLocations`, `configDataResultsData`, and probably more as the function evolves.",
        "key": "JSDOC#RETURNS#RESOLVECOREDATA"
      },
      "resolveVariationData": {
        "value": "With a `{success: true}` object, the given variation's own information to be consumed by the Comment Variables CLI and the Comment Variables VS Code extension, namingly its own `originalFlattenedConfigData`, its own `aliases_flattenedKeys`, its own `flattenedConfigData`, its own `reversedFlattenedConfigData`, and accessorily its own `configDataResultsData`.",
        "key": "JSDOC#RETURNS#RESOLVEVARIATIONDATA"
      }
    },
    "constants": {
      "configKeyRegex": {
        "value": "Ensures keys should only include lowercase letters (`Ll`), uppercase letters (`Lu`), other letters (`Lo`), dash punctuation (`Pd`), connector punctuation (`Pc`), numbers (`N`) and whitespaces (`s`).",
        "key": "JSDOC#CONSTANTS#CONFIGKEYREGEX"
      },
      "flattenedConfigKeyRegex": {
        "value": "Same as `configKeyRegex` but without lowercase letters (`\\p{Ll}`), wthout dash punctuation (`Pd`), connector punctuation (`Pc`), whitespaces (`\\s`), which all three are replaced by underscores (`_`), and with the '`#`' character (that links each subkey together).",
        "key": "JSDOC#CONSTANTS#FLATTENEDCONFIGKEYREGEX"
      },
      "flattenedConfigPlaceholderLocalRegex": {
        "value": "Same as `flattenedConfigKeyRegex` but taking the prefix `$COMMENT` and its `#` into consideration, preventing two consecutive `#`'s, removing `^` and `$` in the capture group, and using `_` as replacement for whitespaces.",
        "key": "JSDOC#CONSTANTS#FLATTENEDCONFIGPLACEHOLDERLOCALREGEX"
      },
      "flattenedConfigPlaceholderGlobalRegex": {
        "value": "Same as `flattenedConfigPlaceholderLocalRegex` but globally.",
        "key": "JSDOC#CONSTANTS#FLATTENEDCONFIGPLACEHOLDERGLOBALREGEX"
      },
      "extractRuleConfigData": {
        "value": "The core data needed to run the \"extract\" rule, fully-named `\"extract-object-string-literal-values\"`. (The name of the object could eventually be changed for being too function-sounding, since it could be confused for \"a function that extract rule config data\" instead of what it is, \"the data of the extract rule config\".)",
        "key": "JSDOC#CONSTANTS#EXTRACTRULECONFIGDATA"
      }
    }
  },
  "forComposedVariables": {
    "pluginName": {
      "value": "plugin",
      "key": "FORCOMPOSEDVARIABLES#PLUGINNAME"
    },
    "ruleName": {
      "value": "rule",
      "key": "FORCOMPOSEDVARIABLES#RULENAME"
    },
    "theNameOf": {
      "value": "The name of the",
      "key": "FORCOMPOSEDVARIABLES#THENAMEOF"
    },
    "forFilteringPeriod": {
      "value": "being used for filtering.",
      "key": "FORCOMPOSEDVARIABLES#FORFILTERINGPERIOD"
    },
    "flattenedConfigDataB": {
      "value": "The flattened config data",
      "key": "FORCOMPOSEDVARIABLES#FLATTENEDCONFIGDATAB"
    },
    "aliases_flattenedKeys": {
      "value": "The aliases-to-flattened-keys dictionary",
      "key": "FORCOMPOSEDVARIABLES#ALIASES_FLATTENEDKEYS"
    },
    "configDataB": {
      "value": "The original config data",
      "key": "FORCOMPOSEDVARIABLES#CONFIGDATAB"
    },
    "obtainedResolveConfig": {
      "value": "obtained from resolveConfig.",
      "key": "FORCOMPOSEDVARIABLES#OBTAINEDRESOLVECONFIG"
    },
    "recursivelyResolvesTo": {
      "value": "Recursively resolves Comment Variables config data values (being strings or nested objects) to generate an",
      "key": "FORCOMPOSEDVARIABLES#RECURSIVELYRESOLVESTO"
    },
    "createsThat": {
      "value": "Creates that",
      "key": "FORCOMPOSEDVARIABLES#CREATESTHAT"
    },
    "objectConfigData": {
      "value": "object with the same keys and the same shape as the original config data now with all string values entirely resolved.",
      "key": "FORCOMPOSEDVARIABLES#OBJECTCONFIGDATA"
    },
    "transformedObjectConfigData": {
      "value": "object with the same keys and the same base shape as the original config data now with all string values entirely resolved alongside Comment Variables keys.",
      "key": "FORCOMPOSEDVARIABLES#TRANSFORMEDOBJECTCONFIGDATA"
    },
    "makesThe": {
      "value": "Makes the",
      "key": "FORCOMPOSEDVARIABLES#MAKESTHE"
    },
    "resolvedAnExpected": {
      "value": "resolved config data to be written at an expected",
      "key": "FORCOMPOSEDVARIABLES#RESOLVEDANEXPECTED"
    },
    "pathPeriod": {
      "value": " path.",
      "key": "FORCOMPOSEDVARIABLES#PATHPERIOD"
    },
    "jsonCaps": {
      "value": "JSON",
      "key": "FORCOMPOSEDVARIABLES#JSONCAPS"
    },
    "dotJsonPathPeriod": {
      "value": "`.json` path.",
      "key": "FORCOMPOSEDVARIABLES#DOTJSONPATHPERIOD"
    },
    "mjsCaps": {
      "value": "MJS",
      "key": "FORCOMPOSEDVARIABLES#MJSCAPS"
    },
    "dotMjsPathPeriod": {
      "value": "`.mjs` path.",
      "key": "FORCOMPOSEDVARIABLES#DOTMJSPATHPERIOD"
    },
    "logWritingOfThe": {
      "value": "log that announces the writing of the",
      "key": "FORCOMPOSEDVARIABLES#LOGWRITINGOFTHE"
    },
    "resolvedConfigDataPeriod": {
      "value": "resolved config data.",
      "key": "FORCOMPOSEDVARIABLES#RESOLVEDCONFIGDATAPERIOD"
    },
    "_The": {
      "value": "The",
      "key": "FORCOMPOSEDVARIABLES#_THE"
    },
    "expected": {
      "value": "expected",
      "key": "FORCOMPOSEDVARIABLES#EXPECTED"
    },
    "dotJsonPath": {
      "value": "`.json` path",
      "key": "FORCOMPOSEDVARIABLES#DOTJSONPATH"
    },
    "dotMjsPath": {
      "value": "`.mjs` path",
      "key": "FORCOMPOSEDVARIABLES#DOTMJSPATH"
    },
    "whereThe": {
      "value": "where the",
      "key": "FORCOMPOSEDVARIABLES#WHERETHE"
    },
    "resolvedToBeWritten": {
      "value": "resolved config data is to be written.",
      "key": "FORCOMPOSEDVARIABLES#RESOLVEDTOBEWRITTEN"
    },
    "makeJsonDataReturns": {
      "value": "It can be consumed by any language that can parse JSON, which means virtually all modern languages, so that Comment Variables can act as a single source of truth for text variables beyond JavaScript and TypeScript.",
      "key": "FORCOMPOSEDVARIABLES#MAKEJSONDATARETURNS"
    },
    "makeMjsDataReturns": {
      "value": "Its format makes it possible to be consumed with literal type safety in both JavaScript and TypeScript.",
      "key": "FORCOMPOSEDVARIABLES#MAKEMJSDATARETURNS"
    },
    "resolvedConfigCompleted": {
      "value": "resolved config data has been completed.",
      "key": "FORCOMPOSEDVARIABLES#RESOLVEDCONFIGCOMPLETED"
    },
    "configData": {
      "value": "The config's data property.",
      "key": "FORCOMPOSEDVARIABLES#CONFIGDATA"
    },
    "variationData": {
      "value": "Any provided variation data.",
      "key": "FORCOMPOSEDVARIABLES#VARIATIONDATA"
    },
    "configOrVariationData": {
      "value": "The config's data property or any provided variation data.",
      "key": "FORCOMPOSEDVARIABLES#CONFIGORVARIATIONDATA"
    },
    "variationOrConfigData": {
      "value": "Any provided variation data or the config's data property.",
      "key": "FORCOMPOSEDVARIABLES#VARIATIONORCONFIGDATA"
    },
    "configDataA": {
      "value": "(Values are typed `unknown` given the limitations in typing recursive values in JSDoc.)",
      "key": "FORCOMPOSEDVARIABLES#CONFIGDATAA"
    },
    "configDataC": {
      "value": "(Config data at this time is still `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#CONFIGDATAC"
    },
    "configDataD": {
      "value": "(Config data at this time may still be `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#CONFIGDATAD"
    },
    "variationDataC": {
      "value": "(Variation data at this time is still `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#VARIATIONDATAC"
    },
    "variationDataD": {
      "value": "(Variation data at this time may still be `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#VARIATIONDATAD"
    },
    "configOrVariationDataC": {
      "value": "(Config or variation data at this time is still `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#CONFIGORVARIATIONDATAC"
    },
    "configOrVariationDataD": {
      "value": "(Config or variation data at this time may still be `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#CONFIGORVARIATIONDATAD"
    },
    "variationOrConfigDataC": {
      "value": "(Variation – or config – data at this time is still `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#VARIATIONORCONFIGDATAC"
    },
    "variationOrConfigDataD": {
      "value": "(Variation – or config – data at this time may still be `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#VARIATIONORCONFIGDATAD"
    },
    "__configData": {
      "value": "(Config data",
      "key": "FORCOMPOSEDVARIABLES#__CONFIGDATA"
    },
    "__variationData": {
      "value": "(Variation data",
      "key": "FORCOMPOSEDVARIABLES#__VARIATIONDATA"
    },
    "__configOrVariationData": {
      "value": "(Config or variation data",
      "key": "FORCOMPOSEDVARIABLES#__CONFIGORVARIATIONDATA"
    },
    "__variationOrConfigData": {
      "value": "(Variation or config data",
      "key": "FORCOMPOSEDVARIABLES#__VARIATIONORCONFIGDATA"
    },
    "atThisTime": {
      "value": "at this time",
      "key": "FORCOMPOSEDVARIABLES#ATTHISTIME"
    },
    "isStillUnknown__": {
      "value": "is still `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#ISSTILLUNKNOWN__"
    },
    "mayStillUnknown__": {
      "value": "may still be `unknown`.)",
      "key": "FORCOMPOSEDVARIABLES#MAYSTILLUNKNOWN__"
    }
  }
})