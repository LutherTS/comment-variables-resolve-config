export const resolvedConfigData: {
    "en": {
        "tsDoc": {
            "src": {
                "consts": {
                    "errors": {
                        "messages": {
                            "absolutePathSupposedToBeString": {
                                "value": "`absolutePath` is supposed to be a string.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#ABSOLUTEPATHSUPPOSEDTOBESTRING";
                            };
                            "absolutePathCouldntBeRead": {
                                "value": "Absolute file path could not be read.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#ABSOLUTEPATHCOULDNTBEREAD";
                            };
                            "jsTsJsxTsxCouldntBeParsed": {
                                "value": "JS/TS/JSX/TSX source code could not be parsed.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#JSTSJSXTSXCOULDNTBEPARSED";
                            };
                        };
                        "statuses": {
                            "public": {
                                "ABSOLUTEPATH_NOT_STRING": {
                                    "value": "\"$COMMENT#EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#ABSOLUTEPATHISSUPPOSEDTOBEASTRING\"";
                                    "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#PUBLIC#ABSOLUTEPATH_NOT_STRING";
                                };
                                "ABSOLUTE_PATH_NOT_FOUND": {
                                    "value": "\"Absolute file path could not be read.\"";
                                    "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#PUBLIC#ABSOLUTE_PATH_NOT_FOUND";
                                };
                                "SOURCE_CODE_FATAL_SYNTAX": {
                                    "value": "\"JS/TS/JSX/TSX source code could not be parsed.\"";
                                    "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#PUBLIC#SOURCE_CODE_FATAL_SYNTAX";
                                };
                            };
                        };
                    };
                };
                "lib": {
                    "consts": {
                        "public": {
                            "successFalse": {
                                "value": "Apply last with  `...successFalse` to ensure that `success: false` sits at the top of its object's type definition, like `{propertyA, propertyB, ...successFalse}`.";
                                "key": "EN#TSDOC#SRC#LIB#CONSTS#PUBLIC#SUCCESSFALSE";
                            };
                            "successTrue": {
                                "value": "Apply last with  `...successTrue` to ensure that `success: true` sits at the top of its object's type definition, like `{propertyA, propertyB, ...successTrue}`.";
                                "key": "EN#TSDOC#SRC#LIB#CONSTS#PUBLIC#SUCCESSTRUE";
                            };
                            "typeError": {
                                "value": "Apply last with  `...typeError` to ensure that `type: error` sits at the top of its object's type definition, like `{propertyA, propertyB, ...typeError}`.";
                                "key": "EN#TSDOC#SRC#LIB#CONSTS#PUBLIC#TYPEERROR";
                            };
                            "typeWarning": {
                                "value": "Apply last with  `...typeWarning` to ensure that `type: warning` sits at the top of its object's type definition, like `{propertyA, propertyB, ...typeWarning}`.";
                                "key": "EN#TSDOC#SRC#LIB#CONSTS#PUBLIC#TYPEWARNING";
                            };
                        };
                        "parser": {
                            "public": {
                                "typeScriptAndJSXCompatible": {
                                    "value": "`languageOptions` object for instances of the `ESLint` and `Linter` classes enabling the linting of TypeScript and JSX (React) files.";
                                    "key": "EN#TSDOC#SRC#LIB#CONSTS#PARSER#PUBLIC#TYPESCRIPTANDJSXCOMPATIBLE";
                                };
                            };
                        };
                    };
                    "defs": {
                        "public": {
                            "getSourceCode": {
                                "value": "Gets the ESLint-generated `SourceCode` object of a file from its absolute path.";
                                "key": "EN#TSDOC#SRC#LIB#DEFS#PUBLIC#GETSOURCECODE";
                            };
                        };
                        "utils": {
                            "public": {
                                "makeSuccessFalseTypeError": {
                                    "value": "Makes a `{success: false}` object with a single error in its `errors` array of `{type: error}` based on the `message` it is meant to display and the `status` it is meant to have.";
                                    "key": "EN#TSDOC#SRC#LIB#DEFS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEERROR";
                                };
                                "makeSuccessFalseTypeWarning": {
                                    "value": "Makes a `{success: false}` object with a single error in its `errors` array of `{type: warning}` based on the `message` it is meant to display and the `status` it is meant to have.";
                                    "key": "EN#TSDOC#SRC#LIB#DEFS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEWARNING";
                                };
                            };
                        };
                    };
                    "params": {
                        "public": {
                            "absolutePath": {
                                "value": "The absolute path of the file at hand.";
                                "key": "EN#TSDOC#SRC#LIB#PARAMS#PUBLIC#ABSOLUTEPATH";
                            };
                        };
                        "utils": {
                            "public": {
                                "message": {
                                    "value": "The human-readable message of the error.";
                                    "key": "EN#TSDOC#SRC#LIB#PARAMS#UTILS#PUBLIC#MESSAGE";
                                };
                                "status": {
                                    "value": "The static status text of the error.";
                                    "key": "EN#TSDOC#SRC#LIB#PARAMS#UTILS#PUBLIC#STATUS";
                                };
                            };
                        };
                    };
                    "returns": {
                        "public": {
                            "getSourceCode": {
                                "value": "The ESLint-generated `SourceCode` object of a file, from which the AST (`sourceCode.ast`) and all comments (`sourceCode.getAllComments()`) can be extracted, inside a `{success: true}` object at its `sourceCode` key. In case of an error, a `{success: false}` object is returned instead.";
                                "key": "EN#TSDOC#SRC#LIB#RETURNS#PUBLIC#GETSOURCECODE";
                            };
                        };
                        "utils": {
                            "public": {
                                "makeSuccessFalseTypeError": {
                                    "value": "A `{success: false}` object with a single error in its `errors` array of `{type: error}`.";
                                    "key": "EN#TSDOC#SRC#LIB#RETURNS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEERROR";
                                };
                                "makeSuccessFalseTypeWarning": {
                                    "value": "A `{success: false}` object with a single error in its `errors` array of `{type: warning}`.";
                                    "key": "EN#TSDOC#SRC#LIB#RETURNS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEWARNING";
                                };
                            };
                        };
                    };
                };
                "tests": {
                    "defs": {
                        "utils": {
                            "assertFailureWithMessage": {
                                "value": "Asserts that `getSourceCode` fails when it should.";
                                "key": "EN#TSDOC#SRC#TESTS#DEFS#UTILS#ASSERTFAILUREWITHMESSAGE";
                            };
                            "assertSuccess": {
                                "value": "Asserts that `getSourceCode` succeeds when it should.";
                                "key": "EN#TSDOC#SRC#TESTS#DEFS#UTILS#ASSERTSUCCESS";
                            };
                        };
                    };
                    "params": {
                        "utils": {
                            "getSourceCodeResults": {
                                "value": "The results of the `getSourceCode` instance called in the test, whose success or failure is evaluated via its `success` key's boolean value.";
                                "key": "EN#TSDOC#SRC#TESTS#PARAMS#UTILS#GETSOURCECODERESULTS";
                            };
                            "expectedMessage": {
                                "value": "The expected message of the error that should be encountered during failure, from which the status can be inferred.";
                                "key": "EN#TSDOC#SRC#TESTS#PARAMS#UTILS#EXPECTEDMESSAGE";
                            };
                        };
                    };
                    "returns": {
                        "utils": {
                            "assertFailureWithMessage": {
                                "value": "Void.";
                                "key": "EN#TSDOC#SRC#TESTS#RETURNS#UTILS#ASSERTFAILUREWITHMESSAGE";
                            };
                            "assertSuccess": {
                                "value": "Void.";
                                "key": "EN#TSDOC#SRC#TESTS#RETURNS#UTILS#ASSERTSUCCESS";
                            };
                        };
                    };
                };
            };
        };
        "forComposedVariables": {
            "variables": {
                "getSourceCode": {
                    "value": "getSourceCode";
                    "key": "EN#FORCOMPOSEDVARIABLES#VARIABLES#GETSOURCECODE";
                };
            };
            "arguments": {};
        };
        "composedVariablesExclusives": {
            "variables": {};
            "arguments": {
                "absolutePath": {
                    "value": "absolutePath";
                    "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#ABSOLUTEPATH";
                };
            };
            "successFalse": {
                "value": "successFalse";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUCCESSFALSE";
            };
            "successTrue": {
                "value": "successTrue";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUCCESSTRUE";
            };
            "typeError": {
                "value": "typeError";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#TYPEERROR";
            };
            "typeWarning": {
                "value": "typeWarning";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#TYPEWARNING";
            };
            "success_false": {
                "value": "success: false";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUCCESS_FALSE";
            };
            "success_true": {
                "value": "success: true";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUCCESS_TRUE";
            };
            "type_error": {
                "value": "type: error";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#TYPE_ERROR";
            };
            "type_warning": {
                "value": "type: warning";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#TYPE_WARNING";
            };
            "success": {
                "value": "success";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUCCESS";
            };
            "false": {
                "value": "false";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#FALSE";
            };
            "true": {
                "value": "true";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#TRUE";
            };
            "type": {
                "value": "type";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#TYPE";
            };
            "error": {
                "value": "error";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ERROR";
            };
            "warning": {
                "value": "warning";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#WARNING";
            };
            "_applyLastWith": {
                "value": "Apply last with";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#_APPLYLASTWITH";
            };
            "toEnsure": {
                "value": "to ensure that";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#TOENSURE";
            };
            "sitsAtTopLike": {
                "value": "sits at the top of its object's type definition, like";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SITSATTOPLIKE";
            };
            "propApropB": {
                "value": "propertyA, propertyB";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#PROPAPROPB";
            };
            "eslintSourceCode": {
                "value": "ESLint-generated `SourceCode` object of a file";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ESLINTSOURCECODE";
            };
            "singleError": {
                "value": "single error in its `errors` array";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SINGLEERROR";
            };
            "basedOnMessageAndStatus": {
                "value": "based on the `message` it is meant to display and the `status` it is meant to have";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#BASEDONMESSAGEANDSTATUS";
            };
            "absolutePath": {
                "value": "absolute path of the file";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ABSOLUTEPATH";
            };
            "atHand": {
                "value": "at hand";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ATHAND";
            };
            "_asserts": {
                "value": "Asserts";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#_ASSERTS";
            };
            "whenItShould": {
                "value": "when it should";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#WHENITSHOULD";
            };
            "message": {
                "value": "message";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#MESSAGE";
            };
            "status": {
                "value": "status";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#STATUS";
            };
            "_void": {
                "value": "Void";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#_VOID";
            };
        };
    };
    "fr": {
        "tsDoc": {
            "src": {
                "consts": {
                    "errors": {
                        "statuses": {
                            "public": {
                                "ABSOLUTEPATH_NOT_STRING": {
                                    "value": "En anglais \u00E0 l'ex\u00E9cution : \"`absolutePath` is supposed to be a string.\"";
                                    "key": "FR#TSDOC#SRC#CONSTS#ERRORS#STATUSES#PUBLIC#ABSOLUTEPATH_NOT_STRING";
                                };
                                "ABSOLUTE_PATH_NOT_FOUND": {
                                    "value": "En anglais \u00E0 l'ex\u00E9cution : \"Absolute file path could not be read.\"";
                                    "key": "FR#TSDOC#SRC#CONSTS#ERRORS#STATUSES#PUBLIC#ABSOLUTE_PATH_NOT_FOUND";
                                };
                                "SOURCE_CODE_FATAL_SYNTAX": {
                                    "value": "En anglais \u00E0 l'ex\u00E9cution : \"JS/TS/JSX/TSX source code could not be parsed.\"";
                                    "key": "FR#TSDOC#SRC#CONSTS#ERRORS#STATUSES#PUBLIC#SOURCE_CODE_FATAL_SYNTAX";
                                };
                            };
                        };
                    };
                };
                "lib": {
                    "consts": {
                        "public": {
                            "successFalse": {
                                "value": "\u00C0 apposer en dernier via  `...successFalse` pour s'assurer que `success: false` apparaisse au sommet de la d\u00E9finition du type de l'objet auquel il appartient, fa\u00E7on `{propertyA, propertyB, ...successFalse}`.";
                                "key": "FR#TSDOC#SRC#LIB#CONSTS#PUBLIC#SUCCESSFALSE";
                            };
                            "successTrue": {
                                "value": "\u00C0 apposer en dernier via  `...successTrue` pour s'assurer que `success: true` apparaisse au sommet de la d\u00E9finition du type de l'objet auquel il appartient, fa\u00E7on `{propertyA, propertyB, ...successTrue}`.";
                                "key": "FR#TSDOC#SRC#LIB#CONSTS#PUBLIC#SUCCESSTRUE";
                            };
                            "typeError": {
                                "value": "\u00C0 apposer en dernier via  `...typeError` pour s'assurer que `type: error` apparaisse au sommet de la d\u00E9finition du type de l'objet auquel il appartient, fa\u00E7on `{propertyA, propertyB, ...typeError}`.";
                                "key": "FR#TSDOC#SRC#LIB#CONSTS#PUBLIC#TYPEERROR";
                            };
                            "typeWarning": {
                                "value": "\u00C0 apposer en dernier via  `...typeWarning` pour s'assurer que `type: warning` apparaisse au sommet de la d\u00E9finition du type de l'objet auquel il appartient, fa\u00E7on `{propertyA, propertyB, ...typeWarning}`.";
                                "key": "FR#TSDOC#SRC#LIB#CONSTS#PUBLIC#TYPEWARNING";
                            };
                        };
                        "parser": {
                            "public": {
                                "typeScriptAndJSXCompatible": {
                                    "value": "Objet `languageOptions` pour instances de classes `ESLint` et `Linter` permettant l'analyse statique de fichiers TypeScript et JSX (React).";
                                    "key": "FR#TSDOC#SRC#LIB#CONSTS#PARSER#PUBLIC#TYPESCRIPTANDJSXCOMPATIBLE";
                                };
                            };
                        };
                    };
                    "defs": {
                        "public": {
                            "getSourceCode": {
                                "value": "Obtient l'objet `SourceCode` g\u00E9n\u00E9r\u00E9 par ESLint d'un fichier \u00E0 partir de son chemin absolu.";
                                "key": "FR#TSDOC#SRC#LIB#DEFS#PUBLIC#GETSOURCECODE";
                            };
                        };
                        "utils": {
                            "public": {
                                "makeSuccessFalseTypeError": {
                                    "value": "Cr\u00E9e un objet `{success: false}` avec une seule erreur dans son array `errors` de `{type: error}` bas\u00E9e sur le `message` qu'elle doit montrer et le `status` qu'elle doit avoir.";
                                    "key": "FR#TSDOC#SRC#LIB#DEFS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEERROR";
                                };
                                "makeSuccessFalseTypeWarning": {
                                    "value": "Cr\u00E9e un objet `{success: false}` avec une seule erreur dans son array `errors` de `{type: warning}` bas\u00E9e sur le `message` qu'elle doit montrer et le `status` qu'elle doit avoir.";
                                    "key": "FR#TSDOC#SRC#LIB#DEFS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEWARNING";
                                };
                            };
                        };
                    };
                    "params": {
                        "public": {
                            "absolutePath": {
                                "value": "Le chemin absolu du fichier concern\u00E9.";
                                "key": "FR#TSDOC#SRC#LIB#PARAMS#PUBLIC#ABSOLUTEPATH";
                            };
                        };
                        "utils": {
                            "public": {
                                "message": {
                                    "value": "Le message en clair de l'erreur.";
                                    "key": "FR#TSDOC#SRC#LIB#PARAMS#UTILS#PUBLIC#MESSAGE";
                                };
                                "status": {
                                    "value": "Le texte statique du statut de l'erreur.";
                                    "key": "FR#TSDOC#SRC#LIB#PARAMS#UTILS#PUBLIC#STATUS";
                                };
                            };
                        };
                    };
                    "returns": {
                        "public": {
                            "getSourceCode": {
                                "value": "L'objet `SourceCode` g\u00E9n\u00E9r\u00E9 par ESLint d'un fichier, \u00E0 partir duquel l'AST (`sourceCode.ast`) et tous les commentaires (`sourceCode.getAllComments()`) peuvent \u00EAtre extraits, \u00E0 l'int\u00E9rieur d'un objet `{success: true}` \u00E0 sa cl\u00E9 `sourceCode`. En cas d'erreur, un objet `{success: false}` est retourn\u00E9 \u00E0 la place.";
                                "key": "FR#TSDOC#SRC#LIB#RETURNS#PUBLIC#GETSOURCECODE";
                            };
                        };
                        "utils": {
                            "public": {
                                "makeSuccessFalseTypeError": {
                                    "value": "Un objet `{success: false}` avec une seule erreur dans son array `errors` de `{type: error}`.";
                                    "key": "FR#TSDOC#SRC#LIB#RETURNS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEERROR";
                                };
                                "makeSuccessFalseTypeWarning": {
                                    "value": "Un objet `{success: false}` avec une seule erreur dans son array `errors` de `{type: warning}`.";
                                    "key": "FR#TSDOC#SRC#LIB#RETURNS#UTILS#PUBLIC#MAKESUCCESSFALSETYPEWARNING";
                                };
                            };
                        };
                    };
                };
            };
        };
        "forComposedVariables": {};
        "composedVariablesExclusives": {
            "_enAnglais": {
                "value": "En anglais \u00E0 l'ex\u00E9cution";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#_ENANGLAIS";
            };
            "error": {
                "value": "erreur";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#ERROR";
            };
            "_applyLastWith": {
                "value": "\u00C0 apposer en dernier via";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#_APPLYLASTWITH";
            };
            "toEnsure": {
                "value": "pour s'assurer que";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#TOENSURE";
            };
            "sitsAtTopLike": {
                "value": "apparaisse au sommet de la d\u00E9finition du type de l'objet auquel il appartient, fa\u00E7on";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#SITSATTOPLIKE";
            };
            "eslintSourceCode": {
                "value": "objet `SourceCode` g\u00E9n\u00E9r\u00E9 par ESLint d'un fichier";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#ESLINTSOURCECODE";
            };
            "singleError": {
                "value": "seule erreur dans son array `errors`";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#SINGLEERROR";
            };
            "basedOnMessageAndStatus": {
                "value": "bas\u00E9e sur le `message` qu'elle doit montrer et le `status` qu'elle doit avoir";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#BASEDONMESSAGEANDSTATUS";
            };
            "absolutePath": {
                "value": "chemin absolu du fichier";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#ABSOLUTEPATH";
            };
            "concern\u00E9": {
                "value": "concern\u00E9";
                "key": "FR#COMPOSEDVARIABLESEXCLUSIVES#CONCERN\u00C9";
            };
        };
    };
};
