import { EN, FR } from "../index.js";

import { enData } from "./en/index.js";
import { frData } from "./fr/index.js";

export const data = Object.freeze({
  [EN]: enData,
  [FR]: frData,
});
