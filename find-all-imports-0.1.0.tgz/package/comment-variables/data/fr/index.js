/* data */

export const frData = Object.freeze({});

/* manual commentVariablesExclusives */

export const frComposedVariablesExclusives = /** @type {string[]} */ ([]);
