export const zodStaticErrorMessages_errorStatuses: Readonly<{
    "`filePath` is supposed to be a string.": "FILEPATH_NOT_STRING";
    "`filePath` is supposed to end with `.js`. (Only regular JavaScript files are supported.)": "FILEPATH_NOT_END_WITH_DOT_JS";
    "`visitedSet` is supposed to be a Set.": "VISITEDSET_NOT_SET";
    "`visitedSet` values are supposed to be strings.": "VISITEDSET_VALUES_NOT_STRINGS";
    "`depth` is supposed to be a number.": "DEPTH_NOT_NUMBER";
    "`maxDepth` is supposed to be a number.": "MAXDEPTH_NOT_NUMBER";
}>;
export const allStaticErrorMessages_errorStatuses: Readonly<{
    "Input data could not pass validation from zod.": "INPUT_DATA_INVALID";
    "`filePath` is supposed to be a string.": "FILEPATH_NOT_STRING";
    "`filePath` is supposed to end with `.js`. (Only regular JavaScript files are supported.)": "FILEPATH_NOT_END_WITH_DOT_JS";
    "`visitedSet` is supposed to be a Set.": "VISITEDSET_NOT_SET";
    "`visitedSet` values are supposed to be strings.": "VISITEDSET_VALUES_NOT_STRINGS";
    "`depth` is supposed to be a number.": "DEPTH_NOT_NUMBER";
    "`maxDepth` is supposed to be a number.": "MAXDEPTH_NOT_NUMBER";
}>;
export const zodStaticErrorStatuses: readonly ["FILEPATH_NOT_STRING", "FILEPATH_NOT_END_WITH_DOT_JS", "VISITEDSET_NOT_SET", "VISITEDSET_VALUES_NOT_STRINGS", "DEPTH_NOT_NUMBER", "MAXDEPTH_NOT_NUMBER"];
export const allStaticErrorStatuses: readonly ["INPUT_DATA_INVALID", "FILEPATH_NOT_STRING", "FILEPATH_NOT_END_WITH_DOT_JS", "VISITEDSET_NOT_SET", "VISITEDSET_VALUES_NOT_STRINGS", "DEPTH_NOT_NUMBER", "MAXDEPTH_NOT_NUMBER"];
export const allDynamicErrorStatuses: readonly ["MAX_DEPTH_REACHED", "FILE_PATH_FILE_NOT_FOUND"];
export const getSourceCodeError: {
    type: "error";
    message: string;
    status: string;
};
