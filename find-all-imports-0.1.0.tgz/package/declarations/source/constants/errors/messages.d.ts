export const inputDataCouldntPassZod: "Input data could not pass validation from zod.";
export const filePathSupposedToBeString: "`filePath` is supposed to be a string.";
export const filePathSupposedToEndWithDotJs: "`filePath` is supposed to end with `.js`. (Only regular JavaScript files are supported.)";
export const visitedSetSupposedToBeSet: "`visitedSet` is supposed to be a Set.";
export const visitedSetValuesSupposedToBeStrings: "`visitedSet` values are supposed to be strings.";
export const depthSupposedToBeNumber: "`depth` is supposed to be a number.";
export const maxDepthSupposedToBeNumber: "`maxDepth` is supposed to be a number.";
