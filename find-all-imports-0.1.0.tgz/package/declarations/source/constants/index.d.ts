export const DEFAULT_DEPTH: number;
export const DEFAULT_MAX_DEPTH: number;
export const DOT_JS: ".js";
