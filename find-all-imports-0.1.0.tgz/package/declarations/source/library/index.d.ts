export function findAllImports<T extends string>(filePath: T, { visitedSet, depth, maxDepth, }?: {
    visitedSet?: Set<string> | undefined;
    depth?: number | undefined;
    maxDepth?: number | undefined;
}): {
    readonly success: false;
    readonly errors: readonly [{
        readonly type: "error";
        readonly message: `ERROR. Max depth ${number} reached at ${T}.`;
        readonly status: "MAX_DEPTH_REACHED";
    }];
} | {
    readonly success: false;
    readonly errors: readonly [{
        readonly type: "error";
        readonly message: `ERROR. File not found at ${T}.`;
        readonly status: "FILE_PATH_FILE_NOT_FOUND";
    }];
} | {
    readonly success: false;
    readonly errors: readonly [{
        readonly type: "error";
        readonly message: "ERROR. Input data could not pass validation from zod.";
        readonly status: "INPUT_DATA_INVALID";
    }, ...{
        type: "error";
        message: "`filePath` is supposed to be a string." | "`filePath` is supposed to end with `.js`. (Only regular JavaScript files are supported.)" | "`visitedSet` is supposed to be a Set." | "`visitedSet` values are supposed to be strings." | "`depth` is supposed to be a number." | "`maxDepth` is supposed to be a number.";
        status: "FILEPATH_NOT_STRING" | "FILEPATH_NOT_END_WITH_DOT_JS" | "VISITEDSET_NOT_SET" | "VISITEDSET_VALUES_NOT_STRINGS" | "DEPTH_NOT_NUMBER" | "MAXDEPTH_NOT_NUMBER";
    }[]];
} | {
    readonly success: false;
    readonly errors: readonly [{
        type: "error";
        message: string;
        status: string;
    }, ...{
        type: "error";
        message: "Absolute file path could not be read." | "`absolutePath` is supposed to be a string." | "JS/TS/JSX/TSX source code could not be parsed.";
        status: "ABSOLUTEPATH_NOT_STRING" | "ABSOLUTE_PATH_NOT_FOUND" | "SOURCE_CODE_FATAL_SYNTAX";
    }[]];
} | {
    readonly success: true;
    readonly visitedSet: Set<string>;
};
export type FindAllImportsResults = import("../typedefs/index.js").FindAllImportsResults;
