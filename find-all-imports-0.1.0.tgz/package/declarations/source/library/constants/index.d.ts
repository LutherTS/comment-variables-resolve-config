export const resolver: ResolverFactory;
import { ResolverFactory } from "oxc-resolver";
