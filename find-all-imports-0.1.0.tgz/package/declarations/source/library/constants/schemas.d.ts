export const InputDataSchema: z.ZodObject<{
    filePath: z.ZodString;
    visitedSet: z.ZodSet<z.ZodString>;
    depth: z.ZodNumber;
    maxDepth: z.ZodNumber;
}, z.core.$strip>;
import * as z from "zod";
