export const resolvedConfigData: {
    "en": {
        "tsDoc": {
            "src": {
                "consts": {
                    "DEFAULT_DEPTH": {
                        "value": "0";
                        "key": "EN#TSDOC#SRC#CONSTS#DEFAULT_DEPTH";
                    };
                    "DEFAULT_MAX_DEPTH": {
                        "value": "100";
                        "key": "EN#TSDOC#SRC#CONSTS#DEFAULT_MAX_DEPTH";
                    };
                    "errors": {
                        "messages": {
                            "inputDataCouldntZod": {
                                "value": "Input data could not pass validation from zod.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#INPUTDATACOULDNTZOD";
                            };
                            "filePathSupposedToBeString": {
                                "value": "`filePath` is supposed to be a string.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#FILEPATHSUPPOSEDTOBESTRING";
                            };
                            "filePathSupposedToEndWithDotJs": {
                                "value": "`filePath` is supposed to end with `.js`. (Only regular JavaScript files are supported.)";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#FILEPATHSUPPOSEDTOENDWITHDOTJS";
                            };
                            "visitedSetSupposedToBeSet": {
                                "value": "`visitedSet` is supposed to be a Set.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#VISITEDSETSUPPOSEDTOBESET";
                            };
                            "visitedSetValuesSupposedToBeStrings": {
                                "value": "`visitedSet` values are supposed to be strings.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#VISITEDSETVALUESSUPPOSEDTOBESTRINGS";
                            };
                            "depthSupposedToBeNumber": {
                                "value": "`depth` is supposed to be a number.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#DEPTHSUPPOSEDTOBENUMBER";
                            };
                            "maxDepthSupposedToBeNumber": {
                                "value": "`maxDepth` is supposed to be a number.";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#MESSAGES#MAXDEPTHSUPPOSEDTOBENUMBER";
                            };
                        };
                        "statuses": {
                            "INPUT_DATA_INVALID": {
                                "value": "\"Input data could not pass validation from zod.\"";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#INPUT_DATA_INVALID";
                            };
                            "FILEPATH_NOT_STRING": {
                                "value": "\"`filePath` is supposed to be a string.\"";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#FILEPATH_NOT_STRING";
                            };
                            "FILEPATH_NOT_END_WITH_DOT_JS": {
                                "value": "\"`filePath` is supposed to end with `.js`. (Only regular JavaScript files are supported.)\"";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#FILEPATH_NOT_END_WITH_DOT_JS";
                            };
                            "VISITEDSET_NOT_SET": {
                                "value": "\"`visitedSet` is supposed to be a Set.\"";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#VISITEDSET_NOT_SET";
                            };
                            "VISITEDSET_VALUES_NOT_STRINGS": {
                                "value": "\"`visitedSet` values are supposed to be strings.\"";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#VISITEDSET_VALUES_NOT_STRINGS";
                            };
                            "DEPTH_NOT_NUMBER": {
                                "value": "\"`depth` is supposed to be a number.\"";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#DEPTH_NOT_NUMBER";
                            };
                            "MAXDEPTH_NOT_NUMBER": {
                                "value": "\"`maxDepth` is supposed to be a number.\"";
                                "key": "EN#TSDOC#SRC#CONSTS#ERRORS#STATUSES#MAXDEPTH_NOT_NUMBER";
                            };
                        };
                    };
                };
            };
        };
        "composedVariablesExclusives": {
            "variables": {
                "findAllImports": {
                    "value": "findAllImports";
                    "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#VARIABLES#FINDALLIMPORTS";
                };
            };
            "arguments": {
                "filePath": {
                    "value": "filePath";
                    "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#FILEPATH";
                };
                "visitedSet": {
                    "value": "visitedSet";
                    "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#VISITEDSET";
                };
                "depth": {
                    "value": "depth";
                    "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#DEPTH";
                };
                "maxDepth": {
                    "value": "maxDepth";
                    "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#MAXDEPTH";
                };
            };
            "supposedTo": {
                "value": "supposed to";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUPPOSEDTO";
            };
            "supposedToString": {
                "value": "supposed to be a string";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUPPOSEDTOSTRING";
            };
            "supposedToSet": {
                "value": "supposed to be a Set";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUPPOSEDTOSET";
            };
            "supposedToStrings": {
                "value": "supposed to be strings";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUPPOSEDTOSTRINGS";
            };
            "supposedToNumber": {
                "value": "supposed to be a number";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SUPPOSEDTONUMBER";
            };
            "string": {
                "value": "string";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#STRING";
            };
            "Set": {
                "value": "Set";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#SET";
            };
            "strings": {
                "value": "strings";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#STRINGS";
            };
            "number": {
                "value": "number";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#NUMBER";
            };
            "dotJs": {
                "value": ".js";
                "key": "EN#COMPOSEDVARIABLESEXCLUSIVES#DOTJS";
            };
        };
    };
    "fr": {};
};
