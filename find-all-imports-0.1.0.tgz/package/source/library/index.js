import fs from "fs";

import {
  getSourceCode,
  successFalse,
  typeError,
  makeSuccessFalseTypeError,
  successTrue,
} from "get-sourcecode";

import {
  DEFAULT_DEPTH,
  DEFAULT_MAX_DEPTH,
  DOT_JS,
} from "../constants/index.js";
import {
  allStaticErrorMessages_errorStatuses,
  zodStaticErrorMessages_errorStatuses,
  getSourceCodeError,
} from "../constants/errors/index.js";
import { inputDataCouldntPassZod } from "../constants/errors/messages.js";
import {
  MAX_DEPTH_REACHED,
  FILE_PATH_FILE_NOT_FOUND,
} from "../constants/errors/statuses.js";

import { resolver } from "./constants/index.js";
import { InputDataSchema } from "./constants/schemas.js";

/**
 * @typedef {import("../typedefs/index.js").FindAllImportsResults} FindAllImportsResults
 */

/* Primary export */

export const findAllImports = /** @template {string} T */ (
  /** @type {T} */ filePath,
  {
    visitedSet = /** @type {Set<string>} */ (new Set()),
    depth = DEFAULT_DEPTH,
    maxDepth = DEFAULT_MAX_DEPTH,
  } = {},
) => {
  // validations

  // for validations only, not extracting data; `visitedSet` should NOT be reassigned
  const inputDataSchemaResults = InputDataSchema.safeParse({
    filePath,
    visitedSet,
    depth,
    maxDepth,
  });

  if (!inputDataSchemaResults.success) {
    return /** @type {const} */ ({
      errors: [
        {
          message: `ERROR. ${inputDataCouldntPassZod}`,
          status: allStaticErrorMessages_errorStatuses[inputDataCouldntPassZod],
          ...typeError,
        },
        ...inputDataSchemaResults.error.issues.map((e) => {
          const message =
            /** @type {keyof typeof zodStaticErrorMessages_errorStatuses} */
            (e.message);

          return {
            message: message,
            status: zodStaticErrorMessages_errorStatuses[message],
            ...typeError,
          };
        }),
      ],
      ...successFalse,
    });
  }

  if (depth > maxDepth)
    return makeSuccessFalseTypeError(
      `ERROR. Max depth ${maxDepth} reached at ${filePath}.`,
      MAX_DEPTH_REACHED,
    );

  if (!fs.existsSync(filePath))
    return makeSuccessFalseTypeError(
      `ERROR. File not found at ${filePath}.`,
      FILE_PATH_FILE_NOT_FOUND,
    );

  const getSourceCodeResults = getSourceCode(filePath);

  if (!getSourceCodeResults.success) {
    return /** @type {const} */ ({
      errors: [
        getSourceCodeError,
        ...getSourceCodeResults.errors.map((e) => {
          return {
            type: e.type,
            message: e.message,
            status: e.status,
          };
        }),
      ],
      ...successFalse,
    });
  }

  // operations

  const { sourceCode } = getSourceCodeResults;

  // Returns the existing set directly if a path has already been visited.
  if (visitedSet.has(filePath))
    return /** @type {const} */ ({ visitedSet, ...successTrue });
  // Updates the visited set otherwise.
  else visitedSet.add(filePath);

  // Processes all top-level imports. (ESM only.)
  for (const node of sourceCode.ast.body) {
    // ES Modules (import x from 'y')
    if (node.type === "ImportDeclaration") {
      const importPath = node.source.value;

      // Returns early if the import path is not a string literal.
      if (typeof importPath !== "string")
        return /** @type {const} */ ({ visitedSet, ...successTrue });

      // Resolves the import path with a ".js"-exclusive, node_modules-excluding resolver.
      const resolvedImportPath = resolver.resolveFileSync(
        filePath,
        importPath,
      ).path;

      // Ensures the import path is resolved, otherwise continues.
      if (!resolvedImportPath) continue;

      // Ensures the resolved import path explictly ends with ".js", otherwise continues. (Which somehow `resolver` doesn't handle even though configured as such.)
      if (!resolvedImportPath.endsWith(DOT_JS)) continue;

      // Tracks the current depth of the recursion.
      const newDepth = depth + 1;

      // Runs findAllImports on the resolved imported path, thus recursively.
      const findAllImportsResults = /** @type {FindAllImportsResults} */ (
        findAllImports(resolvedImportPath, {
          visitedSet,
          depth: newDepth,
          maxDepth,
        })
      );

      // Returns `findAllImportsResults` only in case of failure. (Saving and manually typing `findAllImportsResults` was also a needed step for a correct return type for `findAllImports`.)
      if (!findAllImportsResults.success) return findAllImportsResults;
    }
  }

  // Returns all visited paths once all the respective child runs are complete.
  return /** @type {const} */ ({ visitedSet, ...successTrue });
};
