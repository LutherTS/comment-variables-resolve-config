import * as z from "zod";

import { DOT_JS } from "../../constants/index.js";

import {
  filePathSupposedToBeString,
  filePathSupposedToEndWithDotJs,
  visitedSetSupposedToBeSet,
  visitedSetValuesSupposedToBeStrings,
  depthSupposedToBeNumber,
  maxDepthSupposedToBeNumber,
} from "../../constants/errors/messages.js";

export const InputDataSchema = z.object({
  filePath: z
    .string({
      error: filePathSupposedToBeString,
    })
    .endsWith(DOT_JS, {
      error: filePathSupposedToEndWithDotJs,
    }),
  visitedSet: z.set(z.string({ error: visitedSetValuesSupposedToBeStrings }), {
    error: visitedSetSupposedToBeSet,
  }),
  depth: z.number({ error: depthSupposedToBeNumber }),
  maxDepth: z.number({ error: maxDepthSupposedToBeNumber }),
});
