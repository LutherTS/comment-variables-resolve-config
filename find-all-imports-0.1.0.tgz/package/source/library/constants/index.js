import { ResolverFactory } from "oxc-resolver";

import { DOT_JS } from "../../constants/index.js";

/* import resolver */

export const resolver = new ResolverFactory({
  extensions: [DOT_JS], // focusing exclusively on ".js" files
  modules: [], // voluntarily ignoring "node_modules"
});
