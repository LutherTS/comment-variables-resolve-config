import { resolvedConfigData as commentVariablesData } from "../../comments.config.mjs";

/* constants */

export const consts = commentVariablesData.en.tsDoc.src.consts;
export const messages =
  commentVariablesData.en.tsDoc.src.consts.errors.messages;

/* tests */

export const composedVariablesExclusives =
  commentVariablesData.en.composedVariablesExclusives;

export { commentVariablesData };
