import url from "url";
import path from "path";

import { describe, it } from "node:test";
import assert from "node:assert";

import { DEFAULT_MAX_DEPTH, DOT_JS } from "../constants/index.js";
import { getSourceCodeError } from "../constants/errors/index.js";
import {
  filePathSupposedToBeString,
  filePathSupposedToEndWithDotJs,
  visitedSetSupposedToBeSet,
  visitedSetValuesSupposedToBeStrings,
  depthSupposedToBeNumber,
  maxDepthSupposedToBeNumber,
} from "../constants/errors/messages.js";
import {
  MAX_DEPTH_REACHED,
  FILE_PATH_FILE_NOT_FOUND,
} from "../constants/errors/statuses.js";

import { findAllImports } from "../library/index.js";

import {
  FIND_ALL_IMPORTS,
  FILE_PATH,
  VISITED_SET,
  DEPTH,
  MAX_DEPTH,
} from "./constants/index.js";

import {
  assertFailureWithMessage,
  assertFailureWithStatus,
} from "./utilities/index.js";

const currentDirectoryPath = path.dirname(url.fileURLToPath(import.meta.url));

const toCommentsConfigFilePath = "../../comments.config.js";
const commentsConfigFilePath = path.join(
  currentDirectoryPath,
  toCommentsConfigFilePath,
);

const toFatalFilePath = "./fatal/file.js";
const fatalFilePath = path.join(currentDirectoryPath, toFatalFilePath);

describe(FIND_ALL_IMPORTS, () => {
  // initial tests

  it("should be a function", () => {
    const findAllImportsType = typeof findAllImports;
    assert.strictEqual(findAllImportsType, "function");
  });

  it(`should be named \`${FIND_ALL_IMPORTS}\``, () => {
    const findAllImportsName = findAllImports.name;
    assert.strictEqual(findAllImportsName, FIND_ALL_IMPORTS);
  });

  // input validation tests (zod)

  it(`should error if \`${FILE_PATH}\` param is not a string`, () => {
    const findAllImportsResults = findAllImports(2);
    assertFailureWithMessage(findAllImportsResults, filePathSupposedToBeString);
  });

  it(`should error if \`${FILE_PATH}\` does not end with \`${DOT_JS}\``, () => {
    const findAllImportsResults = findAllImports("string.json");
    assertFailureWithMessage(
      findAllImportsResults,
      filePathSupposedToEndWithDotJs,
    );
  });

  it(`should error if \`${VISITED_SET}\` option is not a Set`, () => {
    const findAllImportsResults = findAllImports(commentsConfigFilePath, {
      visitedSet: 4,
    });
    assertFailureWithMessage(findAllImportsResults, visitedSetSupposedToBeSet);
  });

  it(`should error if \`${VISITED_SET}\` values are not strings`, () => {
    const findAllImportsResults = findAllImports(commentsConfigFilePath, {
      visitedSet: new Set([5]),
    });
    assertFailureWithMessage(
      findAllImportsResults,
      visitedSetValuesSupposedToBeStrings,
    );
  });

  it(`should error if \`${DEPTH}\` option is not a number`, () => {
    const findAllImportsResults = findAllImports(commentsConfigFilePath, {
      depth: false,
    });
    assertFailureWithMessage(findAllImportsResults, depthSupposedToBeNumber);
  });

  it(`should error if \`${MAX_DEPTH}\` option is not a number`, () => {
    const findAllImportsResults = findAllImports(commentsConfigFilePath, {
      maxDepth: true,
    });
    assertFailureWithMessage(findAllImportsResults, maxDepthSupposedToBeNumber);
  });

  // input validation tests (specifics)

  it(`should error if \`${DEPTH}\` is greater than \`${MAX_DEPTH}\``, () => {
    const findAllImportsResults = findAllImports(commentsConfigFilePath, {
      depth: DEFAULT_MAX_DEPTH + 1,
    });
    assertFailureWithStatus(findAllImportsResults, MAX_DEPTH_REACHED);
  });

  it(`should error if \`${FILE_PATH}\` is not found`, () => {
    const findAllImportsResults = findAllImports("notFound.js");
    assertFailureWithStatus(findAllImportsResults, FILE_PATH_FILE_NOT_FOUND);
  });

  it(`should error if \`${FILE_PATH}\` has invalid syntax`, () => {
    const findAllImportsResults = findAllImports(fatalFilePath);
    assertFailureWithStatus(findAllImportsResults, getSourceCodeError.status);
  });

  // operations tests

  it(`should succeed here with a Set of size 5`, () => {
    const findAllImportsResults = findAllImports(commentsConfigFilePath);
    console.debug("findAllImportsResults are:", findAllImportsResults);
    assert.strictEqual(findAllImportsResults.success, true);
    assert.strictEqual(findAllImportsResults.visitedSet.size, 5);
  });

  it(`should error here with a status of "MAX_DEPTH_REACHED"`, () => {
    const findAllImportsResults = findAllImports(commentsConfigFilePath, {
      maxDepth: 1,
    });
    console.debug("findAllImportsResults are:", findAllImportsResults);
    assert.strictEqual(findAllImportsResults.success, false);
    assert.strictEqual(
      findAllImportsResults.errors.some((e) => e.status === MAX_DEPTH_REACHED),
      true,
    );
  });
});
