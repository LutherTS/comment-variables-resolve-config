import assert from "node:assert";

import { allStaticErrorMessages_errorStatuses } from "../../constants/errors/index.js";

/**
 * @typedef {import("../../typedefs/index.js").ErrorMessages_ErrorStatuses__Key} ErrorMessages_ErrorStatuses__Key
 * @typedef {import("../../typedefs/index.js").FindAllImportsReturnType} FindAllImportsReturnType
 * @typedef {import("../../typedefs/index.js").DynamicErrorStatus} DynamicErrorStatus
 */

/* assert */

export const assertFailureWithMessage =
  /** @template {ErrorMessages_ErrorStatuses__Key} T */ (
    /** @type {FindAllImportsReturnType} */ findAllImportsResults,
    /** @type {T} */ expectedMessage,
  ) => {
    assert.strictEqual(findAllImportsResults.success, false);
    assert.strictEqual(
      findAllImportsResults.errors.some(
        (e) =>
          e.message === expectedMessage &&
          e.status === allStaticErrorMessages_errorStatuses[expectedMessage],
      ),
      true,
    );
  };

export const assertFailureWithStatus = /** @template {DynamicErrorStatus} T */ (
  /** @type {FindAllImportsReturnType} */ findAllImportsResults,
  /** @type {T} */ expectedStatus,
) => {
  assert.strictEqual(findAllImportsResults.success, false);
  assert.strictEqual(
    findAllImportsResults.errors.some((e) => e.status === expectedStatus),
    true,
  );
};
