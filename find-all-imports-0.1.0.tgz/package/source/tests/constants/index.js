import { composedVariablesExclusives } from "../../comment-variables/index.js";

/* primary export names */

/** $COMMENT#COMPOSEDVARIABLESEXCLUSIVES#VARIABLES#FINDALLIMPORTS */
export const FIND_ALL_IMPORTS =
  composedVariablesExclusives.variables.findAllImports.value;

/** $COMMENT#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#FILEPATH */
export const FILE_PATH = composedVariablesExclusives.arguments.filePath.value;

/** $COMMENT#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#VISITEDSET */
export const VISITED_SET =
  composedVariablesExclusives.arguments.visitedSet.value;
/** $COMMENT#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#DEPTH */
export const DEPTH = composedVariablesExclusives.arguments.depth.value;
/** $COMMENT#COMPOSEDVARIABLESEXCLUSIVES#ARGUMENTS#MAXDEPTH */
export const MAX_DEPTH = composedVariablesExclusives.arguments.maxDepth.value;
