import {
  consts,
  composedVariablesExclusives,
} from "../comment-variables/index.js";

/* default parameters */

/** $COMMENT#EN#TSDOC#SRC#CONSTS#DEFAULT_DEPTH */
export const DEFAULT_DEPTH = +consts.DEFAULT_DEPTH.value;
/** $COMMENT#TSDOC#SRC#CONSTS#DEFAULT_MAX_DEPTH */
export const DEFAULT_MAX_DEPTH = +consts.DEFAULT_MAX_DEPTH.value;

/* supporting schemas */

export const DOT_JS = composedVariablesExclusives.dotJs.value;
