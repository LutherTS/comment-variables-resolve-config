import { messages } from "../../comment-variables/index.js";

/* messages for static errors */

export const inputDataCouldntPassZod = messages.inputDataCouldntZod.value;

export const filePathSupposedToBeString =
  messages.filePathSupposedToBeString.value;
export const filePathSupposedToEndWithDotJs =
  messages.filePathSupposedToEndWithDotJs.value;

export const visitedSetSupposedToBeSet =
  messages.visitedSetSupposedToBeSet.value;
export const visitedSetValuesSupposedToBeStrings =
  messages.visitedSetValuesSupposedToBeStrings.value;

export const depthSupposedToBeNumber = messages.depthSupposedToBeNumber.value;

export const maxDepthSupposedToBeNumber =
  messages.maxDepthSupposedToBeNumber.value;
