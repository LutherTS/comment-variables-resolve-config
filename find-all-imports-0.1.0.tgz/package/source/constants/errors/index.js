import { getSourceCode, typeError } from "get-sourcecode";

import {
  inputDataCouldntPassZod,
  filePathSupposedToBeString,
  filePathSupposedToEndWithDotJs,
  visitedSetSupposedToBeSet,
  visitedSetValuesSupposedToBeStrings,
  depthSupposedToBeNumber,
  maxDepthSupposedToBeNumber,
} from "./messages.js";
import {
  INPUT_DATA_INVALID,
  FILEPATH_NOT_STRING,
  FILEPATH_NOT_END_WITH_DOT_JS,
  VISITEDSET_NOT_SET,
  VISITEDSET_VALUES_NOT_STRINGS,
  DEPTH_NOT_NUMBER,
  MAXDEPTH_NOT_NUMBER,
  MAX_DEPTH_REACHED,
  FILE_PATH_FILE_NOT_FOUND,
} from "./statuses.js";

/* error messages to error statuses */

export const zodStaticErrorMessages_errorStatuses = Object.freeze({
  [filePathSupposedToBeString]: FILEPATH_NOT_STRING,
  [filePathSupposedToEndWithDotJs]: FILEPATH_NOT_END_WITH_DOT_JS,
  [visitedSetSupposedToBeSet]: VISITEDSET_NOT_SET,
  [visitedSetValuesSupposedToBeStrings]: VISITEDSET_VALUES_NOT_STRINGS,
  [depthSupposedToBeNumber]: DEPTH_NOT_NUMBER,
  [maxDepthSupposedToBeNumber]: MAXDEPTH_NOT_NUMBER,
});

export const allStaticErrorMessages_errorStatuses = Object.freeze({
  ...zodStaticErrorMessages_errorStatuses,
  [inputDataCouldntPassZod]: INPUT_DATA_INVALID,
});

/* error statuses arrays */

export const zodStaticErrorStatuses = /** @type {const} */ ([
  FILEPATH_NOT_STRING,
  FILEPATH_NOT_END_WITH_DOT_JS,
  VISITEDSET_NOT_SET,
  VISITEDSET_VALUES_NOT_STRINGS,
  DEPTH_NOT_NUMBER,
  MAXDEPTH_NOT_NUMBER,
]);

export const allStaticErrorStatuses = /** @type {const} */ ([
  INPUT_DATA_INVALID,
  ...zodStaticErrorStatuses,
]);

export const allDynamicErrorStatuses = /** @type {const} */ ([
  MAX_DEPTH_REACHED,
  FILE_PATH_FILE_NOT_FOUND,
]);

/* library errors */

export const getSourceCodeError = {
  message: `ERROR. \`${getSourceCode.name}\` error.`,
  status: `${getSourceCode.name.toUpperCase()}_ERROR.`,
  ...typeError,
};
